![133149924-e6949257-3aa5-4564-9977-f96fe4640967](https://user-images.githubusercontent.com/93199689/177007559-8ff9a779-80ce-4ccd-ac96-5a0e7b9fd423.png)

### Hazırlayan: Hüseyin UZUNYAYLA / OgnitorenKs
- ► Discord: OgnitorenKs#2737 
- ► Mail: ognitorenks@gmail.com
- ► Site: [https://ognitorenks.com.tr](https://ognitorenks.com.tr)
- ► <B> [Projeye Katkıda Bulunanlar](https://github.com/OgnitorenKs/OgnitorenKs.Toolbox/blob/main/Projeye-Katk%C4%B1da-Bulunanlar.md) </B>

# OGNİTORENKS TOOLBOX
![cmd_weccV1gqyA](https://user-images.githubusercontent.com/93199689/193428393-8ddb0888-2fde-4a37-87bb-27e479f75140.png)

- OgnitorenKs Toolbox Windows 10 - 11 sürümlerinin x64 mimarilerinde açılmaktadır. En güncel olan Windows sürümü ile senkronize olarak gelişmektedir.
- Windows ekran ölçeklendirme ayarı Toolbox'ın pencere ayarını bozabiliyor. Sorunsuz kullanım için Toolbox'ı kullanırken ölçeklendirme etkileri kapatılmalıdır.
- Toolbox'ı bazı antivirüsler zararlı olarak işaretlemektedir. Sorunsuz kullanım için beyaz listeye alınması gerekmektedir. 
-  ► [Virüstotal](https://www.virustotal.com/gui/file/1932909b2b70d8155b2fbc27c14b390c1ebf8bbcbdaac856ef3f0f46c4853bc5?nocache=1)
- Geliştirme sürecinde iki ayrı sürüm üzerinde çalışmak zor olduğu için İngilizce dil desteği kaldırılmıştır. Tek bir dosya üzerinden çoklu dil desteği ekleyebilirsem ilerleyen süreçte yeniden eklenecektir :(

# OGNİTORENKS TOOLBOX İÇERİĞİ
<details><B><summary> 1 - Uygulama Yükleyici</B></summary>
----
Bu bölümdeki programların büyük çoğunluğu ücretsiz uygulamalar arasında seçilmiştir.

![cmd_hwfcW39jKk](https://user-images.githubusercontent.com/93199689/188331249-0092939a-bb1d-477d-b0e9-cdd8335a5a4e.png)
![cmd_otDomifS1u](https://user-images.githubusercontent.com/93199689/185706427-a2b5cb1d-33f6-4fdd-9027-aca214dc8583.png)

	• 1M - All in One Runtimes: C++ 2005-2022 / Java / XNA Framework / OpenAL / DirectX. Bu programlar oyunlar ve bazı uygulamalarda sorun yaşamamanız için mutlaka kurulmalıdır.
		• 1M tuşlarsanız All in One Runtimes içindeki programları tek tek veya toplu yükleyebileceğiniz menüye aktarılırsınız.
#### ► Mesajlaşma Uygulamaları 
	• 2 - Discord: Sunucu kurup arkadaşlarınız sohbet edebileceğiniz bir uygulama. Online oyun oynuyorsanız arkadaşlarınızla iletişim kurmak için birebirdir.
	• 3 - Whatsapp: Telefondaki uygulamayı bilgisayarınıza senkronize etmeyi sağlar.
	• 4 - Signal: Telefondaki uygulamayı bilgisayarınıza senkronize etmeyi sağlar.
	• 5 - Telegram: Telefondaki uygulamayı bilgisayarınıza senkronize etmeyi sağlar.
	• 6 - Zoom: Skype benzeri uygulamadır. Eğitim amaçlı kullanılır. 
#### ► Oyun Uygulamaları 
	• 7 - EpicGames: Oyun kütüphanesi. Her hafta verdiği ücretsiz oyunlarla piyasada tanınır.
	• 8 - Steam: Oyun kütüphanesi. Bu kategorideki en popüler uygulamadır. 
	• 9 - GOG Galaxy= CD Project şirketine aittir. Eski birçok oyunu buradan satın alarak oynayabilirsiniz. Diğer oyun kütüphanelerini uygulamaya entegre edebiliyorsunuz.
	• 10 - Uplay: Ubisoft şirketinin oyun kütüphane uygulamasıdır.
	• 11 - Origin: EA Games şirketinin oyun kütühane uygulamasıdır.
	• 12 - Wemod: Hile kütüphanesidir. Yalnızca hikayeli oyunlarda işe yarar.
#### ► Ram Temizleme Uygulamaları
	• 13 - ISLC: RamStandby(bekleme) listesini temizlemeye yarayan uygulamadır.
	• 14- Mem Reduct: Ram içinde boşta bekleyen tüm işlemleri kapatır. Oyunlarda bu temizleme işleminde kasma yaşanabilir.
#### ► Tarayıcı Uygulamaları
	• 15 - Google Chrome: En çok kullanılan tarayıcıdır. 
	• 16 - Mozilla Firefox: Genellikle Linux sistemlerde kullanılır. Windows sürümünde de çok güzel özellik bulunmaktadır.
	• 17 - Brave: Chromium tabanlı tarayıcıdır. Entegre reklam engelleyicisi vardır. Google web mağazasından uygulama indirebilir. Cripto para cüzdanı gibi özellikleri var.
	• 18 - Microsoft Edge: Microsoft herkes kullansın diye Windows'un her yerine mayın gibi döşediği tarayıcıdır. Chromuim tabanlıdır. Hızlı bir tarayıcıdır. Google web mağazasına bağlanabilir.
	• 19 - OperaGX: Özel bir kullanıcı deneyimi sağlayan tarayıcı.
#### ► Sıkıştırma 
	• 20 - 7-Zip: Kullanıcılar genellikle WinRaR uygulamasını kullanır ancak 7-Zip yabana atılacak bir uygulama değildir.
	• 21 - WinRaR: Ücretli ama ücretsizdir!
### ► MultiMedya
	• 22 - Kdenlive: Ücretsizdir. 92 MB civarında bir uygulamadır. Kullanımı çok basittir. Çıktı işlemlerinde ekran kartını kullanmama sorunu halledilirse çok iyi uygulamadır.
	• 23 - Openshot: Ücretsiz video düzenleme uygulamasıdır.
	• 24 - Shotcut: Ücretsiz video düzenleme uygulamasıdır.
	• 25 - Krita: Adobe Photoshop uygulamasının ücretsiz alternatifidir. Steam uygulamasından satın alarak destekte olabilirsiniz. 
	• 26 - Gimp: Adobe Photoshop uygulamasının ücretsiz alternatifidir.
	• 27 - OBS Studio: Ekran kaydı alma işlemi dışında canlı yayınlar içinde kullanılır. Kayıtlarınıza marka logosu atmaz.
	• 28 - ShareX: Ekran görüntüsü (SS) alma yazılımıdır. Ses kaydı almadan ekran kaydedebilir. GIF oluştabilir. Daha sayısız özellik bulunur.
	• 29 - Audacity: Ses düzeltme uygulamasıdır.
	• 30 - JpegView: Görsel açma uygulaması.
	• 31 - HandBrake: Video dönüştürme sıkıştırma uygulaması.
	• 32 - FileConverter: Video-ses ve farklı dosyaları dönüştürmeyi sağlar.
#### ► Multimedia Uygulamaları
	• 33 - K-Lite Codec: Video izleme uygulamasıdır. Açamayacağı video dosyası yoktur. 
	• 34 - VLC Media Player: Video izleme uygulamasıdır. Açamayacağı video dosyası yoktur. Videolarla ilgili çok fazla özelliğe sahiptir.
	• 35 - PotPlayer: Video izleme uygulamasıdır.
	• 36 - Aimp: Ses dosyalarını açmaya yarayan uygulamadır. Tasarım ve özellikle olarak çok beğendiğimi belirtmek isterim.
	• 37 - Spotify: Müzik kitaplığı
#### ► İndirme Araçları
	• 38 - Free Download Manager: İndirme işlemlerinde kullanılacak yardımcı program. Torrent indirme desteğide bulunmaktadır.
	• 39 - Internet Download Manager: Free Download Manager ile hemen hemen aynı işlevlere sahiptir.
	• 40 - EagleGet: İndirme yardımcısı.
	• 41 - ByClick Downloader: Youtube'dan video indirmeye yarayan uygulamadır.
	• 42 - Qbittorrent: Torrent indirme yazılımıdır.
#### ► Office Uygulamaları
	• 43 - LibreOffice: Microsoft Office uygulamasının ücretsiz alternatifidir. 
	• 44 - Adobe Reader: PDF dosyalarını açar.
	• 45 - PDF-XChange Editör: PDF dosyalarını düzenleyip, okuyabilirsiniz. Adobe Reader alternatifidir. Ücretsiz özellikleri bakımından Adobe Reader'den daha iyi bir uygulamdır.
	• 46 - Calibre: E-kitap formundaki dosyaları açıp, okumanızı sağlar.
#### ► Developer
	• 47 - Notepad++: Bilmeyen için not defteri uygulamasıdır. Yazılımcılar için kod editörüdür.
	• 48 - Python: Programlama dilidir.
	• 49 - Visual Studio Code: Visual Studio'nun editör halidir. Genelde web geliştirme için kullanılır.
	• 50 - Github Desktop: Grafik arayüzlü bir git istemcisidir.
	• 51 - Git: Dağıtım takip sistemidir.
	• 52 - Node.JS: Java script kullanılarak server tabanlı uygulama geliştirebilirsiniz.
	• 53 - Unity Hub: Oyun motorudur. Oyun oluşturmanızı sağlar.
	• 54 - Blender: Ücretsiz, açık kaynaklı bir çalışmadır. 3D tasarımlarda kullanılacak mükemmel uygulama.
#### ► Uzak Bağlantı
	• 55 - TeamViewer: Bilgisayarlar arası uzaktan bağlantı sağlar.
	• 56 - AnyDesk: Bilgisayalar arası uzak bağlantı sağlar.
#### ► Temizlik
	• 57 - Hibit Uninstaller: Kalıntı bırakmadan program kaldırmayı sağlar. Ayrıca çöp dosya temizler. Market uygulamalarını da kaldırabilir.
	• 58 - Revo Uninstaller: Program kaldırma uygulaması.
	• 59 - Wise Care 365: PC temizlik uygulamasıdır. Tek sürüme verilen ücretsiz pro sürümüdür.
	• 60 - Unlocker: Silinmeyen dosyaları silmeyi sağlar.
#### ► Oyunlar
	• 61 - OSU!: Müzik video oyunduur.
	• 62 - World Of Tanks: Online tank oyunu.
	• 63 - Genshin Impact: Online oyundur.
	• 64 - League Of Legends[TR]: Riot Games'in oyunudur. 5 vs 5 şeklinde karşılaşma yapılır.
	• 65 - League Of Legends[EUW]: Riot Games'in oyunudur. 5 vs 5 şeklinde karşılaşma yapılır.
	• 66 - Valorant: Riot Games'in CS:GO tarzı oyunudur.
#### ► Görev Çubuğu / Başlat Menüsü
	• 67 - Openshell: Alternatif başlat menüsü
	• 68 - TaskbarX: Görev çubuğunda özelleştirme yapmanızı sağlar.
#### ► Diğer
	• 69 - MSI Afterburner: GPU fan ayarı yapar, SS alır, Video kaydı alır, oyunlarda donanımların kullanım değerlerini gösterir, voltaj değerlerini değiştirebilirsiniz.
	• 70 - Everything: Sistemdeki dosyaları arayıp bulmanızı sağlar. Çok kullanışlı bir programdır.
	• 71 - Hamachi: Ortak bir ağ kurmaya yarayan yazılımdır. Online oyunlarda arkadaşlarınızla oyun kurmak için ortak bir ağ gerektiğinde hayat kurtaran bir programdır.
	• 72 - GlassWire: İnternet takip programı. Bilgisayarınızda hangi program nereye ne göndermiş ne almış hepsini görebilirsiniz.
	• 73 - WARP: Cloudflare'in DNS/VPN hizmetidir. Ücretsizdir. 
</details>

<details><B><summary> 2 - Araç Yükleyici</B></summary>

![Clover_rtfpEZPUmc](https://user-images.githubusercontent.com/93199689/188331256-c4066adb-a7ad-4f5a-91f4-9716a9eb1658.png)

#### ► Windows Düzenleme
	• 1 - NTLite: Sistem düzenleme işleminde kullanılır. En kullanışlı ve kapsamlı yazılımlardandır. Ücretsiz özellikleriyle performans sürüm düzenlemesi yapılabilir.
	• 2 - Dism++: Sistem düzenleme uygulamasıdır. Açık kaynaktır. Arayüzü çok kullanışlıdır. NTLite göre daha basittir.
#### ► USB Hazırlayıcı
	• 3 - Rufus: Windows kurulum diski oluşturmanızı sağlar.
#### ► Donanım Bilgisi
	• 4 - AIDA64: Donanımınız hakkında bilgi alabileceğiniz program.
	• 5 - CPU-Z: İşlemci ve Ram hakkında bilgi verir.
	• 6 - GPU-Z: Ekran kartı hakkında bilgi verir. 
	• 7 - HW Info: Donanım ve kullanım değerleri hakkında bilgi alabilirsiniz.
	• 8 - CrystalDiskInfo: HDD ve SSD sağlık durumu hakkında bilgi verir.
	• 9 - HD Sentinel: HDD ve SSD sağlık durumu hakkında bilgi verir.
	• 10 - Core Temp: İşlemci sıcaklığını öğrenebilirsiniz.
#### ► Test Araçları
	• 11 - CrystalDiskMark: HDD ve SSD'leri test edip okuma/yazma değerlerini öğrenbilirsiniz.
	• 12 - Prime95: İşlemciyi yük altına sokarak test etmenizi sağlar. Overclock işlemlerinin vazgeçilmezidir.
	• 13 - OCCT: CPU / GPU / PSU stress test uygulaması
	• 14 - Furmark: GPU stress test uygulaması
#### ► Sanal Makine
	• 15 - VirtualBox: Sanal makina uygulaması. Tüm Windows sürümleri ve Linux sistemleri kurabilirsiniz.
#### ► Simge Düzenleme
	• 16 - GreenFish: Simge hazırlayıp, simge dosyalarının içeriğine bakabileceğiniz uygulamadır.
	• 17 - Thumbico: Programların .exe dosyasından simge almayı sağlar.
	• 18 - Quick Any 2 ICO: Görsel dosyaları Icon dosyasına çevirmeyi sağlar.
	• 19 - Resource Hacker: .dll .exe gibi dosyaları editleyebileceğiniz kapsamlı bir yazılım.
#### ► Sistem Araçları
	• 20 - NSudo: Dosyaları yüksek yetkili(Trusted Installer) olarak çalıştırmayı sağlayan uygulama.
	• 21 - Explorer++: Alternatif Explorer yazılımıdır. Kritik durumlarda hayat kurtarabilir.
#### ► GPU / Driver Araçları
	• 22 - Display Driver Uninstaller (DDU): Ekran kartı driverını kaldırıp sorunsuz temiz kurulum yapmayı sağlar.
	• 23 - Nvidia Profile Inspector: NVIDIA sürücüleri hakkında detaylı bilgi, performans takibi ve ayarlarda düzenleme yapma imkanı veren başarılı bir uygulama.
	• 24 - RadeonMod: AMD ekran kartı driverıyla ilgili detaylı değişiklikler yapmanızı sağlayan yazılım.
	• 25 - Radeon Software Slimmer: Ekran kartı kurulumuyla ilgili çok fazla seçenek sunarak ihtiyaç dışı özellikleri devre dışı bırakmanızı sağlar.
	• 26 - NVCCleanstall: NVIDIA ekran kartı driver kurulumunda fazla seçenek sunarak ihtiyaç dışı özellikleri yüklememenizi sağlar.
	• 27 - Snappy Driver Installer: Driver güncelleme, yükleme uygulamasıdır. Ücretsizdir. Herhangi bir kısıtlam söz konusu değildir. Sayfaları üzerinden yapımcılarına destek olabilirsiniz.
	• 28 - Geforce Experience: Nvidia ekran kartı driver yükleme aracı.
#### ► Diğer
	• 29 - SSD Booster: SSD sağlığının uzaması için bazı indexleme ve SSD'ler için gereksiz hızlandırma servislerini devre dışı bırakmanızı sağlar. SSD'ye harici olarak hız vermez.
	• 30 - Folder2ISO: Klasörleri ISO'ya dönüştürebileceğiniz basit, küçük bir uygulama.
	• 31 - Process Monitor: Olası sorunlarda analiz yapabilmek için log dosyası oluşturmanızı sağlar.
	• 32 - AOMEI Partition Assistans: Disk yönetimi uygulamasıdır.
	• 33 - Spotify Adblocker: Spotify ücretsiz sürümünde çıkan sesli reklamlar geldiğinde ses sisteminde Spotify'ın sesini kapatır. Böylece reklam dinlemekten kurtulursunuz. Programın yapımcısı 'Mehmet Güdük'tür. Reklam engelleyici çalıştırdığınızda açık değil ise Spotify'da açmaktadır. Böylece her Spotify açtığınızda reklam engelleyici açma derdiniz de bulunmuyor. Ücretsiz sürüm kullananlar programı mutlaka yüklemeli.
	   ► Resmi Sayfası: https://github.com/mehmetguduk/Spotify-Adblocker
</details>

<details><B><summary> 3 - Görev Çubuğu Yöneticisi</B></summary>
	
![cmd_bmhFjeytPW](https://user-images.githubusercontent.com/93199689/193428423-5ef2dcc9-c0e2-4bd7-a82f-96da05a0fc17.png)

	• 1 - Taskbar saat yanı simge ayarı [GÖSTER/GİZLE]: 
	     •[Göster]: 0 - Saat yanında yer alan tüm simgeleri gösterir.
	     •[Gizle]: 1 - Saat yanında yer alan simgelerden ağ ve ses dışındaki simgeleri "▲" içine alır
		
	• 2 - Bildirim Alanı [Aç/Kapat]: 
	     •[Aç]: 0 - Saat sağında yer alan bildirim alanını açar.
	     •[Kapat]: 1 - Saat sağında yer alan bildirim alanını kapatır.
	
	• 3 - Taskbar Hava Durumu [Aç/Kapat]:
	     •[Kapat]: 0 - Görev çubuğundaki hava durumu simgesini kaldırır.
	     •[Aç]: 1 - Görev çubuğundaki hava durumu simgesini ve ayarlarını geri getirir.
	
	• 4 - Taskbar Simge Konumu [Sol/Orta]:
	     •[Sol]: 0 - Görev çubuğundaki simgeleri sola dayar.
	     •[Orta]: 1 - Görev çubuğundaki simgeleri ortalar. (Varsayılan)	
	

</details>

<details><B><summary> 4 - Hizmetleri Yönet</B></summary>

Bu bölümü kullanmak için işlem yapacağınz bölümün numarasını girip daha sonra aç / kapat baş harflerini eklemek gerekiyor.

Örnek: 1a / 2k / 4A / 10K / 23a / 24k  

![cmd_sjXAghXnW6](https://user-images.githubusercontent.com/93199689/193428433-01c1c1a1-fc44-430b-b981-e361af670eb5.png)

	► Hizmetler
	• 1 [A/K]- Bluetooth : Bluetooth hizmetlerini kapatır açar.
	• 2 [A/K]- Telefon: Telefon uygulamasına ait hizmetleri kapatır açar.
	• 3 [A/K]- Yazıcı: Yazıcı hizmetlerini kapatır açar.
	• 4 [A/K]- Tarayıcı ve Kamera: Tarayıcı ve kamera hizmetlerini açar. Buradaki kamera hizmetleri cihazın birden fazla ugulama tarafından kullanılmasını düzenlemektedir.
	• 5 [A/K]- Kalem ve Dokunmatik: Dokunmatik cihazlar için ilgili hizmetleri açar, kapatır.
	• 6 [A/K]- Fax: Fax cihazı için ilgili hizmet ve bileşeneleri açıp, kapatır.
	• 7 [A/K]- Bitlocker Sürücü Şifreleme: Sürücü şifreleme hizmetini açar, kapatır.
	• 8 [A/K]- Tarifeli ağları : Kotalı internetiniz var, kota aşımını önlemek için bu hizmeti kullanabilirsiniz. (Nasıl oluyor hiç bilmiyorum, yalnızca hizmeti açıyorum :D)
	• 9 [A/K]- IP Yardımcısı (IPv6): IPv6 desteği için ağ hizmetleri açar. Yaygın bir kullanım alanı yoktur.
	• 10 [A/K]- Mobil Etkin Nokta: WIFI donanımıyla cihaz üzerinden internet yayınlamaya sağlayan hizmetleri açar, kapatır.
	• 11 [A/K]- Radyo ve Uçak Modu: Windows 11'de kapatılması engellenmiştir, yalnızca açabilirsiniz. Windows 10'da açıp, kapatabilirsiniz. Windows 11'de kapatılırsa görev çubuğundan ağ simgesi kaybolmaktadır.
	• 12 [A/K]- Windows Şimdi Bağlan (WPS): WPS hizmetlerini açar, kapatır.
	• 13 [A/K]- WIFI: WIFI hizmetlerini açar kapatır.
	• 14 [A/K]- Konum: Konum hizmetlerini açar, kapatır.
	• 15 [A/K]- Miracast: WIFI üzerinden kablosuz ekran aktarma hizmetlerini açar, kapatır.
	• 16 [A/K/o]- Akış: Ağ üzerindeki cihazları görme, ağ üzerinden dosya paylaşımı gibi hizmetlri açar, kapatır.
	• 17 [A/K]- Uzak Masaüstü: Uzak masaüstü hizmetleri açar, kapatır.
	• 18 [A/K]- Hızlı Getir (Sysmain): Fazla kullanılan dosyaları önbellekleme yaparak, daha hızlı bir hizmet sunmaya çalışır, ancak bu yüksek disk kullanımına sebep olabilir. SSD varsa gereksiz bir hizmettir. Ancak HDD varsa açmanız gerekebilir.
	• 19 [A/K]- Hızlı Başlat (Hibernate): Bilgisayarın daha hızlı açılması için son kapatma öncesi önbellekleme yapar. Sistemi yeniden açarken bu önbellek dosyasından faydalanır. Açık olması hatalara neden olabilir. Buradaki işlem hizmeti doğrudan açmaz. Yalnızca üzerindeki kilidi açar. İlgili ayar bölümünden yeniden açılması gerekmektedir.
	• 20 [A/K]- Windows Search: Uzak masaüstü, Akış ve Miracast hizmetlerinden ihtiyaç duyulabilir.
	• 21 [A/K]- Xbox: Xbox hizmetini açar kapatır. Xbox'ı tamamen kaldırmaz yalnızca pasif ve kullanılmaz hale getirir.
	• 22 [A/K]- Karma Gerçeklik(VR): Karma gerçeklik hizmetinlerini açar, kapatır. Bileşen yüklemesi veya kaldırması yapmaz.
	• 23 [A/K]- Tanı İlkesi (Uyumluluk): Uyumluluk hizmetini açar, kapatır.
	• 24 [A/K]- Hızlı Kullanıcı Değiştir: Hızlı kullanıcı değiştirme hizmeti ve ayarını açar, kapatır.
	• 25 [A/K]- Yazı Tipi Önbelliği: Sık kullanılan fontları önbelleğe alarak açılış hızını arttırır. Bu hizmetleri açıp, kapatır.
	• 26 [A/K]- Insider: Insider sürümlere geçmeyi sağlayan hizmeti açar kapatır
	• 27 [A/K]- Biyometrik: Biyometrik cihazlar için gerekli servis. Hello Face için gereklidir.
	• 28 [A/K]- Hyper-V: Hyper-V hizmetlerini açıp kapatmayı sağlar.
	• 29 [A/K]- Sistem Geri Yükleme: Sistem geri yükleme, dosya geçmişi gibi hizmetleri açıp, kapatır.
	• 30 [A/K]- Driver Yükle - Güncelle: Driverları update üzerinden yükleyip güncellemeyi sağlayan hizmet ve ayarları açıp, kapatır.
	• 31 [A/K]- Bellek sıkıştırma: Bellek içindeki verinin belli bir bölümünü sıkıştıran hizmeti kapatır ve açar. Gecikme düşürmek için hizmet kapalı tutulabilir.
	• 32 [A/K]- Disk Birleştirme (Defrag): Disk birleştirme hizmetini açar kapatır. Harddiskler için faydalı hizmettir. Ancak bunu harici programlarla manuel olarak yapmak isterseniz buhizmeti kapatabilirsiniz.
	• 33 [A/K]- Paint: Paint uygulamasını kapatıp, açar.
	• 34 [A/K]- Wordpad: Wordpad uygulamasını kapatıp, açar.
	• 35 [A/K]- Notepad: Notepad uygulamasını kapatıp, açar. Kapatırken sağ-tık yeni metin belgesini korur.
	• 36 [A/K]- Adım kaydedici: Yapılan işlemleri sırasıyla SS alarak yapılan işlemleri nasıl gerçekleştirdiğinizi adım adım kaydederek başkalarıyla paylaşmanızı sağlar.
	• 37 [A/K]- Powershell-ISE: Powershell kod editörünü kaldırıp, yükler.
	• 38 [A/K]- Matematik ifade tanıyıcı: Matematik ifadelerini tanımlamayı sağlayan hizmeti açıp, kapatır
	• 39 [A/K]- Windows Media Player: Windows Media Player açıp, kapatır.
	• 40 [A/K]- Internet Explorer: Internet Explorer kapatıp, açar.
	• 41 [A/K]- Linux için altyapı: Linux için gerekli olan altyapı hizmetlerini açıp, kapatır.
	• 42 [A/K]- Net Framework 3.5: Belli başlı uygulamalar ihtiyaç duymaktadır. Oyun ve programlar için açık kalması oluşacak hataları önler.
	• 43 [A/K]- Net Framework 4.5: Belli başlı uygulamalar ihtiyaç duymaktadır. Oyun ve programlar için açık kalması oluşacak hataları önler.
	• 44 [A/K]- DirectPlay: Eski oyunlar için destek sağlamaktadır.
	• 45 [A/K]- CompactOS: Windows sistemini belli oranda sıkıştırır. 2 ila 4 GB arası alan sağlar. Kurtarma alanı varsa onuda kaldırarak daha büyük bir alan açar. Performans kaybı yaratmaz.
	• 46 [A/K]- Eski Fotoğraf Görüntüleyici: Eski foto görüntüleyiciyi açıp, kapatır.
	• 47 [A/K]- Eski ALT + TAB: ALT + TAB alanını eski basit haline getirir. Alt + Tab'larda yaşanan bazı kasılma sorunlarını önleyebilir.
	• 48 [A/K]- Güncellemeleri 2050'ye ertele: Güncelleştirmeleri 2050 yılına erteler. Driver yükleme ayarı açıksa yükler ancak güncellemeleri dahil etmez.
	• 49 [A/K]- Svchost: Svchost hizmetlerini sistem RAM durumuna göre optimize eder. İşlemci üzerinden büyük bir yük kaldırır. 
	• 50 [ A ]- Nihai Performans: Nihai perfromans ekler ve aktif eder.
	• 51 [A/K]- Oyun Modu: Windows'un oyun modunu açıp, kapatır. Açık olması OBS gibi bazı programlarda sorun yaratabilir.
	• 52 [A/K]- CPU Çekirdek Uyku Modu: CPU çekirdeklerinin uyku moduna geçmesini önler.
	• 53 [A/K]- Reklam engelli hosts: Telemetri / Reklam engelli hosts dosyasını ekler. Eski dosyası hosts.bak olarak aynı dizinde yedekler.
	• 54 [A/K]- Gereksiz aygıtlar: Gecikmeyi düşürmek için bazı önemsiz aygıtları açıp, kapatır.
	• 55 [A/K]- Sahiplik Al: Sağ-Tık Sahiplik al ekler. Silerken veya değiştirirken yetki sorunu yaşarsanız bu bölüm ile kolayca halledebilirsiniz.
	• 56 [A/K]- Yönet: Sağ-Tıka çok işlevli Yönet bölümü ekler, kaldırır.
	• 57 [A/K]- Çalıştırma Seçenekleri: Exe uzantılı dosyaları işlem önceliğini düzenleyerek açmanızı sağlayan bölümü sağ-tıka ekler.
	• 58 [A/K]- Terminal: Windows 11 sistemlerde sağ-tık menüsünde yer alan Terminal bölümü kaldırıp, ekler.
	• 59 [A/K]- Eski Menü: Windows 11 sistemlerde eski sağ tık menüsünü açıp, kapatır.
</details>
<details><B><summary> 5 - Windows Düzenleme</B></summary>
Mavi renkli işlem numaraları 18 numaralı işlem ile alakalıdır.

![cmd_koooLfxNax](https://user-images.githubusercontent.com/93199689/193428452-9ccb120f-5cbd-4f89-bce6-a1370ddce8dd.png)

	• 1 - WIM / ESD Okuyucu: install.wim ve install.esd dosyalarının içeriği hakkında bilgi verir.
	• 2 - AIO Windows Hazırla: İnstall.wim sürümlerini birleştirmeye yarar. "X" tuşu burada çalışmaz.
		► Konu anlatımı için bakınız: https://ognitorenks.blogspot.com/2022/03/toolbox-farkl-windows-surumleri-nasl.html
	• 3 - ISO Hazırla: Windows format dosyalarını ISO'ya dönüştürür. "Edit" klasörü içerisinde .iso dosyanızı bulabilirsiniz. "X" tuşu burada çalışmaz.
	• 4 - ESD to WIM dönüştürücü: install.esd dosyalarını install.wim olarak dönüştürür. Çoklu seçim yapılabilir. Çoklu seçimlerde seçim arasına virgül koyun. "Örnek; 1,2,3,4" 
	• 5 - İndex silici: install.wim içinde yer alan istemediğiniz sürümleri silebilirsiniz. Çoklu seçim imkanı yoktur.
	• 6 - İmaj Yükle: install.wim dosyasını klasöre çıkarır.
	• 7 - İmaj Yeniden Yükle: Mount edilen dosya toplanmadan bilgisayar resetlenirse klasörü toparlamak veya işlem yapmak için yeniden yüklenmesi gerekir.
	• 8 - İmaj Topla: Mount edilen dosyaları toplar
	• 9 - Regedit Yükle [İmaj]: Offline sistemin regedit kayıtlarını online sisteme entegre ederek değişim yapmanızı sağlar. Detaylı bir konudur. Bu konularda tecrübeniz yoksa bulaşmayın.
	     • Bu bölümü kullanmadan önce sistemi farklı bir program ile mount ettiyseniz programı kapatın. Yoksa hata alırsınız.
	     • Offline sisteme eklenilen regedit kayıtları online sistemden farklı tepkiler verecektir. Lütfen bu durumu göz önünde bulundurun.
	     • Ekleme yapmadan önce aşağıdaki gibi Regedit kayıtlarını düzenlemeniz gerekmektedir.
	     • -------------------------------------------------------------------------------
	     •                 Varsayılan Yol       Entegre edilmiş hali
	     •                ---------------       --------------------
	     •                 [HKLM\SOFTWARE]  ► ► [HKLM\OFF_SOFTWARE]
	     •                          [HKCR]  ► ► [HKLM\OFF_SOFTWARE\Classes]
	     •                   [HKLM\SYSTEM]  ► ► [HKLM\OFF_SYSTEM]
	     •                          [HKCU]  ► ► [HKLM\OFF_HKCU]
	     •                  [HKU\.Default]  ► ► [HKLM\OFF_HKU]
	     • [HKLM\SYSTEM\CurrentControlSet]  ► ► [HKLM\OFF_SYSTEM\ControlSet001]
	     • -------------------------------------------------------------------------------
	     • ► Örnek 1:
	     • ----------
	     • [Varsayılan Yol]: reg add "HKLM\SOFTWARE\Microsoft\Speech_OneCore\Preferences" /v "ModelDownloadAllowed" /t REG_DWORD /d 0 /f
	     • [Entegre edilmiş hali]: reg add "HKLM\OFF_SOFTWARE\Microsoft\Speech_OneCore\Preferences" /v "ModelDownloadAllowed" /t REG_DWORD /d 0 /f
	     • ----------
	     • ► Örnek 2:
	     • ----------
	     • [Varsayılan Yol]: Reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" /v "EnableWebContentEvaluation" /t REG_DWORD /d 0 /f
	     • [Entegre edilmiş hali]: Reg add "HKLM\OFF_HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" /v "EnableWebContentEvaluation" /t REG_DWORD /d 0 /f
	     • ----------
	     • ► Örnek 3:
	     • ----------
	     • [Varsayılan Yol]: Reg add "HKU\.Default\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" /v "PreventOverride" /t REG_DWORD /d 0 /f
	     • [Entegre edilmiş hali]: Reg add "HKLM\OFF_HKU\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" /v "PreventOverride" /t REG_DWORD /d 0 /f
	     • ----------
	     • ► Örnek 4:
	     • ----------
	     • [Varsayılan Yol]: reg add "HKCR\*\shell\runas" /ve /t REG_SZ /d "Sahipliği Al" /f 
	     • [Entegre edilmiş hali]: reg add "HKLM\OFF_SOFTWARE\Classes\*\shell\runas" /ve /t REG_SZ /d "Sahipliği Al" /f 
	     • ----------
	     • ► Örnek 5:
	     • ----------
	     • [Varsayılan Yol]: "HKLM\SYSTEM\CurrentControlSet\Control\FileSystem" /v "LongPathsEnabled" /t REG_DWORD /d 1 /f
	     • [Entegre edilmiş hali]: "HKLM\OFF_SYSTEM\ControlSet001\Control\FileSystem" /v "LongPathsEnabled" /t REG_DWORD /d 1 /f
	     • -------------------------------------------------------------------------------
	• 10 - Regedit Topla [İmaj]: Yüklenilen regedit kayıtlarını toplar. Regedit kayıtlarını yüklerseniz toplamayı unutmayın. Yoksa diğer programlarda hata alırsınız.
	• 11 - Güncelleme Yükleyici [İmaj]: Windows update dosyalarını offline sisteme yükler. Update dosyalarını "Edit\Update" içine atınız.
	     • Sisteme güncelleme kurmak için Microsoft Update Catalog sitesinden Windows sürümünüzü yazarak arama yapın.
		• Çıkan arama sonuçlarında "Cumulative" yazan son güncelleştirmeyi indirip yükleyin. Önceki sürümleri de kapsamaktadır. 
		• Güncelleme dosyalarını indirmek için: 
		  • ► https://www.catalog.update.microsoft.com/
	• 12 - Appx yükleyici [İmaj]: Market uygulama paketlerini offline sisteme yükler. Yükleme dosyalarını "Edit\Appx" içine atınız
	     • Appx dosyalarının indirmek için; 
		• ► https://store.rg-adguard.net/
	• 13 - Driver Yedekle [Yüklü Sistem]: Yüklü sistemden Driverları yedekler. Yedeklediği konum "Edit\Driver\Yedek"
	• 14 - Driver Yükle [İmaj]: Offline sisteme driver entegre eder. Driver dosyalarını "Edit\Driver" klasörü içine atın. Yedek aldıktan sonra bu bölümü seçerseniz, yedekleri imaja yükler.
	• 15 - Setup Düzenle [İmaj]: Windows yükleme dosyalarını özelleştirir. İlk girişte "Files\setup10.zip" dosyasını indirir. Kendinize özel bölüm oluşturmak istiyorsanız. Aşağıdaki linke bakınız.
	• 16 - Yeni Simgeleri yükle [İmaj]: Yeni simgeleri imaja entegre eder. İlk girişte "Files\Newico.zip" dosyasını indirir.
		► Konu anlatımı için bakınız: https://ognitorenks.blogspot.com/2022/03/windows-setup-bolumu-nasl-duzenlenir.html
	• 17 - Katılımsız Program / Ayar ekle [İmaj]: İmaj dosyalarına ilk açılışlarına program yükleyip, ayar ekleme entegre eder.
		• Bu bölüme girmeden önce 'Mount yol tanımla' bölümünden imajı çıkardığınız klasörün yolunu vermelisiniz.
		• İlk açılışta Online / Offline olarak yükleme seçeneğini sorar.
		• Online kurulumda programlar ilk açılışta indirilir, kurulur ve silinir.
		• Offline kurulumda programlar katılımsız kurulum dosyası hazırlandığında indirilir. İlk açılışta yüklenir ve silinir.
		• Bu bölümde ilk işlem olarak 'Katılımsız kurulum yedekle', son işlem olarak 'Yedek katılımsız kurulum ekle' uygulanmalıdır.
		• Çoklu seçim yapılabilir. Tek tek uğraşmanız gerekmez.
		• Bu bölümle ilgili görseller altta yer almaktadır.
		• 29 - Masaüstüne dosya ekle : Masaüstüne atmak istediğiniz dosyaları 'C:\OgnitorenKs.Toolbox\Edit\Desktop' bölümüne atınız.
	• 18 - Mount yol tanımla: Bu bölüm 9 - 11 - 12 - 14 - 16 - 17  bölümleriyle bağlantılıdır. 
	     • Burada tanımlanan klasör yolu ile işlem yapılmaktadır.
	     • Bu bölüm ilk girişte "Edit\Mount" klasör yolunu alır. Mount dosyaları farklı bir klasörde ise 18 numaralı işlem ile değiştirin.
	     
![cmd_gYrOpo7iog](https://user-images.githubusercontent.com/93199689/186950946-7667fdd4-5c9a-4a23-bbae-a26c6708d878.png)
![cmd_z2sx5gAcWu](https://user-images.githubusercontent.com/93199689/186950957-ff456ee7-678c-488a-b666-10d6914d333c.png)

</details>

<details><B><summary> 6 - Hesap ve Lisans Yönetimi</B></summary>
![cmd_TJH2uCD7iq](https://user-images.githubusercontent.com/93199689/193428458-54ea9895-ab0a-4d4a-b6e7-5c3087cba1dd.png

	• 1 - Administrator Aktifleştir: Administrator hesabını açar.
	• 2 - Administrator Kapat: Administrator hesabını kapatır.
	• 3 - Admin grubuna kullanıcı ekle: Admin grubuna kullanıcı eklersiniz.
	• 4 - Yeni Kullanıcı Ekle: Yeni kullanıcı oluşturabilirsiniz.
	• 5 - Kullanıcı Sil: Mevcut bir kullanıcıyı silebilirsiniz.
	• 6 - Şifremi unuttum: Şifre değiştirmek veya şifre oluşturmak için bu bölüm kullanılabilir.
	• 7 - Mevcut Kullanıcıları Göster [*]: Sistemde kayıtlı kullanıcıları gösterir.
	• 8 - Lisans Gir [ipk]: Lisans numaranızı girerek sistemi lisanslayabilirsiniz.
	• 9 - Lisans Durumu [dli]: Lisans durumu hakkında bilgi verir.
	• 10 - Lisans Durumu Detaylı [dlv]: Lisans durumu hakkında detaylı bilgi verir.
	• 11 - Lisans Süresini Öğren [xpr]: Lisans süresi hakkında detaylı bilgi verir.
	• 12 - Lisans Sil [upk]: Sistem kullandığınız lisansı siler.
	• 13 - Lisans Süre Sıfırla [rearm]: Windows 30 günlük deneme sürümü süresini 3 defa uzatabilirsiniz.
</details>
	
<details><B><summary> 7 - Sistem Hakkında</B></summary>
Sistem ve donanım hakkında bilgi verir.

![cmd_mDH1JvgaDM](https://user-images.githubusercontent.com/93199689/167623663-1d3cde57-4f54-48fb-bbce-a33a8e8f220c.png)
</details>
		
<details><B><summary> 8 - Güncelleme Sonrası Temizlik</B></summary>
Düzenlediğim sistemleri güncelleme sonrası ilk haline getirmeye yarar.
</details>
	
<details><B><summary> 9 - Windows / Market Onar</B></summary>
Microsoft'un önerdiği bütün onarma seçeneklerini uygular.
</details>
	
<details><B><summary> 10 - Genel Temizlik</B></summary>
Simge önbelleğini,
Temp klasörlerini,
SoftwareDistribution klasörünü,
GPU driver setup klasörünü,
WinSxS temizliği yapar.
</details>

<details><B><summary> 11 - Simge Hatalarını Onar</B></summary>
Simge önbelleğini temizleyerek arama bölümündeki simge hatasını, masaüstü veya klasör içerisindeki simge hatalarını giderir. 
</details>
	
<details><B><summary> 12 - Ping Ölçer</B></summary>
İçerisinde belirli sitelerin ping durumlarını otomatik gösterir. Alt bölümde yer alan "Ping ölç" bölümüyle istediğiniz site ve IP'nin pingini ölçebilirsiniz.
	
![cmd_LI4e3XcXIt](https://user-images.githubusercontent.com/93199689/188331396-39132ff2-8853-40ee-911a-293d36401fcf.png)

</details>

<details><B><summary> 13 - Fat32 to NTFS</B></summary>
Fat32 olarak formatlanmış USB diskleri veri kaybı olmadan NTFS'ye çevirir. Disk harfini girmeniz gerekmektedir.
	
![cmd_IbpcglgIoZ](https://user-images.githubusercontent.com/93199689/167626995-480e24ba-31b6-4580-ad1d-40fffc936687.png)

</details>

<details><B><summary> 14 - Kayıtlı Wifi Bilgileri [ARCHLEY]</B></summary>
Bu bölümde sisteme girdiğiniz Wifi isim ve şifrelerini görebilirsiniz. Çalışmasını toolbox'a eklediği için Archley'e teşekkür ederim.

</details>

<details><B><summary> 15 - Zaman Ayarlı PC Kapat</B></summary>
Seçilen belirli bir süreden sonra PC otomatik kapatır. PC üzerinde uygulanmış bir oto kapatma işlemi mevcut değilse 'İptal Et' butonu görünmeyecektir.
	
![cmd_qBHeLUqaMj](https://user-images.githubusercontent.com/93199689/177620977-146cfc29-86e0-4553-a472-b4179a1bfb40.png)

</details>

<details><B><summary> 16 - Appx - Güncelleme Yükleyici</B></summary>
Appx ve Update dosyalarını yüklemenizi sağlayan bölümdür. 
Msix yükleme desteği sisteminizde yok ise bu bölüme atacağınız .msix uzantılı uygulamalar yüklenmeyecektir. Bunun için msix desteğinin yüklenmesi gerekmektedir. Düzenleme yaptığım sistemlerin için bu özelliği etkinleştirirek paylaşıyorum.

	• Appx dosyalarıyla ilgili detaylı bilgi için bakınız:https://ognitorenks.blogspot.com/2021/11/rehber-powershell-appx-komutlarnn_9.html
	• Güncelleme dosyalarını indirebileceğiniz site: https://www.catalog.update.microsoft.com/

</details>

<details><B><summary> 17 - Hash Kontrol [SHA-256]</B></summary>
SHA-256 değerlerini karşılaştırmayı sağlar. Karşılatıracağınız SHA256 değerini girip, karşılaştırılacak dosya yolunu girmeniz gerekiyor. Kontrolleri sağlayıp detaylarını işlem sonunda gösterir.

</details>

<details><B><summary> 18 - Kaldırılamayan Uygulamalar </B></summary>
Kaldırılması Microsoft tarafından engellenen bazı uygulamaları kaldırmayı sağlar. Yeniden yüklenemez. Kaldırırken dikkatli olun. Bu bölümün çalışması için PC'de Python kurulu olması gerekmektedir. Kurulu değilse otomatik olarak yüklemektedir. Windows 11'de çalışmamaktadır.

![cmd_cY92Xi0S1f](https://user-images.githubusercontent.com/93199689/177619102-82d56bcf-3a81-4ea4-9ccf-16ffde40436d.png)

	• 1 - Biometrick hizmeti: Parmak okuyucu cihazlar ve Hello Face için gerekli.
	• 2 - Ekran Yakalama: Windows'un kendi ekran yakalama hizmetini kullanmıyorsanız bunu kaldırabilirsiniz. Ekran alıntısı uygulaması buna bağlıdır. Xbox ekran yakalama hizmeti SS ve video özelliği çalışmasına devam edecektir. Bu hizmet ile bağlantısı yoktur.
	• 3 - Cortana: Windows yardımcı uygulamasıdır. Türkçe dil desteği olmadığı için gereksiz bir hizmettir. Ancak dikte gibi hizmetlerle bağlantısı vardır.
	• 4 - Karma Gerçeklik: VR cihazlar için gerekli hizmet.
	• 5 - Ekran Okuma: Ekrandaki yazıları okutan hizmettir. Bu konuda herhangi bir engel söz konusu değil.
	• 6 - Ebeveyn Kontrolleri: Çocuklarınız için PC'de kısıtlama yapabileceğini hizmettir.
	• 7 - Kişiler: Adından her şey anlaşılıyor. PC'de olmasını gerektiren bir hizmet değil.
	• 8 - Windows Defender: Windows Defender kullanmıyorsanız kesinlikle kaldırın.
	• 9 - Güvenli Tarayıcı: E-Sınav sistemleriden kullanılan servis. Sınav sistemi bu hizmete bağlıysa sınav günü sıkıntı yaşarsınız.
	• 10 - Başlat Menüsü: Alternatif başlat menüsü uygulaması kullanmıyorsanız bunu kaldırmayın. Yoksa kritik hata alırsınız. 
	• 11 - Search App (Taskbar Search): Görev çubuğunda yer alan arama hizmetini kapatır. 
	• 12 - Kamera Barkod Tarayıcı: Kamera Barkod tarama hizmetidir. Amacı dışındaki kullanımlarda sorun çıkarıp çıkarmadığı konusunda tespit ettiğim bir durum yok.

</details>

<details><B><summary> 19 - İşlem Önceliği</B></summary>
İstediğiniz uygulamaları regedit üzerinden işlem önceliğini kalıcı olarak değiştirmenizi sağlar.

![cmd_wHyk2JA1A8](https://user-images.githubusercontent.com/93199689/193428478-051e1ea9-467b-440e-8dfb-8f11d52f322a.png)

<details><B><summary> Z - Toolbox Ayarları</B></summary>
Toolbox üzerinde ayar yapıp. Bilgi alabileceğiniz bölüm.

![cmd_LssN6dG8HD](https://user-images.githubusercontent.com/93199689/188331463-5d7d0aee-ed9b-480c-a709-7724ea79e0c5.png)

	• 1 [A/K] - Otomatik Güncelleme: Güncelleştirmeleri otomatik olarak takip edip etmeyeceğini ayarlayabilirsiniz.
	• 2 [A/K] - Log Kayıt: Yapılan işlemlerden sonra kayıt ayarını açıp kapatabilirsiniz.
	• 3 [A/K] - Tarayıcı eklenti ayarı: Tarayıcılar yüklenirken eklenti yüklenip yüklenmeyeceğini ayarlayabilirsiniz.
	• 4 [A/K] - Chocolatey yükleme sistemi: Chocolatey yükleme sistemini açıp kapatmaya yarar.
	• 5 [A/K] - İnternet bağlantı kontrolü: Bazı durumlarda google.com adresine gönderilen pinglerde yaşanan sorunlardan dolayı internet olmasına rağmen indirme işlemlerinde internet yok hatası verebiliyor. Bu tarz bir hata yaşarsanız bu bölümü kapatınız.
	•       6 - Masaüstüne kısayol oluştur
	•       7 - Güncellemeleri kontrol et
	•       8 - Toolbox Rehber (blogspot)
	•       9 - Güncelleme Notları
	•      10 - Hakkımda - İletişim: Bana ulaşabileceğiniz bağlantıları içereren sayfaya yönlendirir.
	
</details>
