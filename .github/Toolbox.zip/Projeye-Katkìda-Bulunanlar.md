### Hazırlayan: Hüseyin UZUNYAYLA / OgnitorenKs
- ► Discord: OgnitorenKs#2737 
- ► Mail: ognitorenks@gmail.com
- ► Site: [ognitorenks.blogspot.com](https://ognitorenks.blogspot.com/)

### Projeye katkıda bulunanlar
	  ----------------------
	  ► Eray Türkay 
	  ----------------------
	  • Sistem Hakkında - RAM soket yapısının eklenmesi.
	  • Sistem Hakkında - Sistem format tarihinin eklenmesi.
	  ----------------------
	  ► KaanBeyhan (Denizlili)
	  ----------------------
	  • İndirme işlemlerinde ilerleme çubuğunun eklenmesi.
	  ---------
   	  ► Archley
   	  ---------
	  • Wifi Crack çalışmasının toolbox'a eklenmesi.
	  • İşlem tamamlandı ekranının eklenmesi.
	  ----------
	  ► maskem76
	  ----------
	  • Hyper-V bölümündeki hatanın giderilmesi.
	  ----------
	  ► Legnica
	  ----------
	  • Windows Search önbelliğinin temizlenmesiyle ilgili komutların eklenmesi.
	  -------
	  ► Finch
	  --------
	  • Yönetici yetkili kısayolun oluşturulması.
