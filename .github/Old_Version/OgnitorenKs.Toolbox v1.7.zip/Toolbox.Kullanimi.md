:: ==============================================================================================================================
::
::       ■■■■■■■   ■■■■■■   ■■    ■■ ■■■■ ■■■■■■■■  ■■■■■■■  ■■■■■■■■  ■■■■■■■■ ■■    ■■ ■■    ■■  ■■■■■■
::      ■■     ■■ ■■    ■■  ■■■   ■■  ■■     ■■    ■■     ■■ ■■     ■■ ■■       ■■■   ■■ ■■   ■■  ■■    ■
::      ■■     ■■ ■■        ■■■■  ■■  ■■     ■■    ■■     ■■ ■■     ■■ ■■       ■■■■  ■■ ■■  ■■   ■■
::      ■■     ■■ ■■   ■■■■ ■■ ■■ ■■  ■■     ■■    ■■     ■■ ■■■■■■■■  ■■■■■■   ■■ ■■ ■■ ■■■■■      ■■■■■■ 
::      ■■     ■■ ■■    ■■  ■■  ■■■■  ■■     ■■    ■■     ■■ ■■   ■■   ■■       ■■  ■■■■ ■■  ■■         ■■
::      ■■     ■■ ■■    ■■  ■■   ■■■  ■■     ■■    ■■     ■■ ■■    ■■  ■■       ■■   ■■■ ■■   ■■  ■■    ■■
::       ■■■■■■■   ■■■■■■   ■■    ■■ ■■■■    ■■     ■■■■■■■  ■■     ■■ ■■■■■■■■ ■■    ■■ ■■    ■■  ■■■■■■ 
:: 
::  Hazırlayan: Hüseyin UZUNYAYLA / OgnitorenKs
::  Toolbox'ı hazırladığım sistemlerde temel programları indirip, basit bir şekilde sistem üzerinde düzenleme yapması için hazırladım.
::  Sürekli olarak güncellenecektir. Toolbox'ı indirmek için aşağıdaki linkleri kullanabilirsiniz.
::  ► https://www.technopat.net/sosyal/konu/ognitorenks-toolbox-kullanimi.1790250/
::
::  OgnitorenKs.Toolbox katılımsız kurulum dosyasını indirmek için aşağıdaki "Toolbox.Update.bat" dosyasını indirip yönetici olarak çalıştırın.
::  ► https://docs.google.com/uc?export=download&id=1JmrWYeNjVopcIP0n9iNkMUCEbQ2SIvpY
::
::  İstek ve önerileriniz olursa, iletişim;
::  ► Discord: OgnitorenKs#2737 
::  ► Mail: ognitorenks@gmail.com
::  ► Site: ognitorenks.blogspot.com (Bu bölüm şu an aktif değil)
::  ► Site: www.technopat.net\Sosyal (Yeni bir konu açıp yada hazırladığım konularda @OgnitorenKs yazarak etiketleyebilirsiniz) 
:: ==============================================================================================================================
::  Projeye katkıda bulunanlar;
::  ---------------------------
::  ► Eray Türkay [470650]
::  ----------------------
::    • Sistem Hakkında - RAM soket yapısının eklenmesi.
::    •	Sistem Hakkında - Sistem format tarihinin eklenmesi.
::  ----------------------
::  ► KaanBeyhan [DOGGEST]
::  ----------------------
::    • İndirme işlemlerinde ilerleme çubuğunun eklenmesi.
::
:: ==============================================================================================================================
::                                                      OGNİTORENK TOOLBOX 
:: ==============================================================================================================================

Görsel anlatım için 'Technopat/Sosyal'deki konuma bakınız: https://www.technopat.net/sosyal/konu/ognitorenks-toolbox-kullanimi.1790250/

Toolbox içerisinde indirme işlemleri yapılıp, sistem düzenlenebilir.

Toolbox Windows 10 - 11 sürümlerinin x64 mimarilerinde açılmaktadır. Farklı sürümler için desteği yoktur. En güncel olan sürüm ile senkronize olarak gelişmektedir. 

1 - Online Katılımsız Bölümü;
=============================
   Bu bölümdeki programların hiçbiri ücretli değildir. Bütün programlar ücretsiz alternatifler arasında seçilmiştir. WinRaR hariç o da ücretli ama ücretsiz bir yazılımdır.	
   
  • 1 - All in One Runtimes: C++ 2005-2019 / Java / XNA Framework / OpenAL / DirectX. Bu programlar oyunlar ve bazı uygulamalarda sorun yaşamamanız için mutlaka kurulmalıdır.
  --------------------------- 
  ► Mesajlaşma Uygulamaları ◄
  ---------------------------
  • 2 - Discord: Sunucu kurup arkadaşlarınız sohpet edebileceğiniz bir uygulama. Online oyun oynuyorsanız arkadaşlarınızla iletişim kurmak için birebirdir.
  • 3 - Whatsapp: Telefondaki uygulamayı bilgisayarınıza senkronize etmeyi sağlar.
  • 4 - Signal: Telefondaki uygulamayı bilgisayarınıza senkronize etmeyi sağlar.
  • 5 - Telegram: Telefondaki uygulamayı bilgisayarınıza senkronize etmeyi sağlar.
  • 6 - Microsoft Teams: Discor uygulaması gibidir. Ancak genelde eğitim amaçlı kullanımlarda kullanılır.
  • 7 - Zoom: Skype benzeri uygulamadır. Eğitim amaçlı kullanımlarıda kullanılır. 
  --------------------- 
  ► Oyun Uygulamaları ◄
  ---------------------
  • 8 - EpicGames: Oyun kütüphanesi. Her hafta verdiği ücretsiz oyunlarla piyasada tanınır.
  • 9 - Steam: Oyun kütüphanesi. Bu kategorideki en popüler uygulamadır. 
 • 10 - GOG Galaxy= CD Project şirketine aittir. Eski birçok oyunu buradan satın alarak oynayabilirsiniz. Diğer oyun kütüphanelerini uygulamaya entegre edebiliyorsunuz.
 • 11 - Uplay: Ubisoft şirketinin oyun kütüphane uygulamasıdır.
 • 12 - Origin: EA Games şirketinin oyun kütühane uygulamasıdır.
  --------------------- 
  ► Hile Uygulamaları ◄
  --------------------- 
  Online oyunlar için değil :)
 • 13 - Cheat Engine: Hile motorudur. Online oyunlarda denemeyin ban yeme ihtimaliniz yüksek. Hikayeli oyunlarda kullanılabilir. (Hileye hayır) 
 • 14 - Wemod: Hile kütüphanesidir. Yalnızca hikayeli oyunlarda işe yarar.
  ----------- 
  ► Oyunlar ◄
  -----------  
 • 15 - League Of Legends: Riot Games'in oyunudur. 5 vs 5 şeklinde karşılaşma yapılır. Sıkıntılı insanlarla oynandığında klavye kırdırabilir. (Sorumlusu ben değilim :D)
 • 16 - Blitz: League Of Legends oyununun yardımcı uygulamasıdır. Hile değildir, ban yeme riski yoktur. Oyun içi rehber görevi görür.
  ------------------------- 
  ► Tarayıcı Uygulamaları ◄
  ------------------------- 
 • 17 - Google Chrome: En çok kullanılan tarayıcıdır. 
 • 18 - Mozilla Firefox: Genellikle Linux sistemlerde genellikle kullanılır. Windows sürümünde de çok güzel özellik bulunmaktadır.
 • 19 - Brave: Chromium tabanlı tarayıcıdır. Entegre reklam engelleyicisi vardır. Google web mağazasından uygulama indirebilir. Cripto para cüzdanı gibi özellikleri var.
 • 20 - Microsoft Edge: Microsoft herkes kullansın diye Windows'un her yerine mayın gibi döşediği tarayıcıdır. Chromuim tabanlıdır. Hızlı bir tarayıcıdır. Google web mağazasına bağlanabilir.
  -----------------------
  ► Office Uygulamaları ◄
  -----------------------
 • 21 - LibreOffice: Microsoft Office uygulamasının ücretsiz alternatifidir. 
 • 22 - PDF-XChange Editör: PDF dosyalarını düzenleyip, okuyabilirsiniz. Adobe Reader alternatifidir. Ücretsiz özellikleri bakımından Adobe Reader'den daha iyi bir uygulamadır.
 • 23 - Notepad++: Bilmeyen için not defteri uygulamasıdır. Yazılımcılar için kod editörüdür.
 • 24 - Calibre: E-kitap formundaki dosyaları açıp, okumanızı sağlar.
  ---------------------------
  ► Sıkıştırma Uygulamaları ◄
  --------------------------- 
 • 25 - 7-Zip: Kullanıcılar genellikle WinRaR uygulamasını kullanır ancak 7-Zip yabana atılacak bir uygulama değildir.
 • 26 - WinRaR: Ücretli ama ücretsizdir! 
  --------------------------------
  ► Video Düzenleme Uygulamaları ◄
  --------------------------------
 • 27 - Kdenlive: Ücretsizdir. 92 MB civarında bir uygulamadır. Kullanımı çok basittir. Çıktı işlemlerinde ekran kartını kullanmama sorunu halledilirse çok iyi uygulamadır.
  --------------------------------
  ► Resim Düzenleme Uygulamaları ◄
  --------------------------------
 • 28 - Krita: Adobe Photoshop uygulamasının ücretsiz alternatifidir. Steam uygulamasından satın alarak destekte olabilirsiniz. 
 • 29 - Gimp: Adobe Photoshop uygulamasının ücretsiz alternatifidir.
  ---------------------------------
  ► Ekran Kayıt (SS) Uygulamaları ◄
  ---------------------------------
 • 30 - OBS Studio: Ekran kaydı alma işlemi dışında canlı yayınlar içinde kullanılır. Kayıtlarınıza marka logosu atmaz.
 • 31 - ShareX: Ekran görüntüsü (SS) alma yazılımıdır. Ses kaydı almadan ekran kaydedebilir. GIF oluştabilir. Daha sayısız özellik bulunur.
  -----------------------------
  ► Ses Düzeltme Uygulamaları ◄
  -----------------------------
 • 32 - Audacity: Ses düzeltme uygulamasıdır. 
  ---------------------------
  ► Multimedia Uygulamaları ◄
  ---------------------------
 • 33 - K-Lite Codec: Video izleme uygulamasıdır. Açamayacağı video dosyası yoktur. 
 • 34 - VLC Media Player: Video izleme uygulamasıdır. Açamayacağı video dosyası yoktur. Videolarla ilgili çok fazla özelliğe sahiptir.
 • 35 - Aimp: Ses dosyalarını açmaya yarayan uygulamadır. Tasarım ve özellikle olarak çok beğendiğimi belirtmek isterim.
  ----------------------------
  ► Dönüştürücü Uygulamaları ◄
  ----------------------------
 • 36 - Any Video Converter: Video ses dönüştürme uygulamasıdır.
  ------------------------
  ► İndirme Uygulamaları ◄
  ------------------------
 • 37 - Free Download Manager: İndirme işlemlerinde kullanılacak yardımcı program. Torrent indirme desteğide bulunmaktadır.
 • 38 - ByClick Downloader: Youtube'dan video indirmeye yarayan uygulamadır.
 • 39 - Utorrent: Torrent indirme yazılımıdır.
  ---------------------
  ► Diğer Uygulamalar ◄
  ---------------------
 • 40 - GlassWire: İnternet takip programı. Bilgisayarınızda hangi program nereye ne göndermiş ne almış hepsini görebilirsiniz.
 • 41 - TeamViewer: Bilgisayarlar arası uzaktan bağlantı sağlar.
 • 42 - Hamachi: Ortak bir ağ kurmaya yarayan yazılımdır. Online oyunlarda arkadaşlarınızla oyun kurmak için ortak bir ağ gerektiğinde hayat kurtaran bir programdır.
 • 43 - Stremio: Torrent üzerinden film izleyebilirsiniz. İzlediğiniz veya izlemek istediğiniz filmeleri kütüphanenize ekleyebilirsiniz. 
 • 44 - ISLC: RamStandby(bekleme) listesini temizlemeye yarayan uygulamadır.
 • 45 - MSI Afterburner: GPU fan ayarı yapar, SS alır, Video kaydı alır, oyunlarda donanımların kullanım değerlerini gösterir, voltaj değerlerini değiştirebilirsiniz.
 • 46 - Hibit Uninstaller: Kalıntı bırakmadan program kaldırmayı sağlar. Ayrıca çöp dosya temizler. Market uygulamalarını da kaldırabilir.
 • 47 - Unlocker: Silinmeyen dosyaları silmeyi sağlar.
 • 48 - OpenShell: Alternatif başlat menüsüdür.
 • 49 - SSD Booster: SSD için sistemi optimize eder.
 • 50 - Everything: Sistemdeki dosyaları arayıp bulmanızı sağlar. Çok kullanışlı bir programdır.
 • 51 - TaskbarX: Başlat çubuğunu özelleştirmenizi sağlar.
  -----------------
  ► ÇOKLU İNDİRME ◄
  -----------------
 • 52 - Çoklu İndirme: Bu bölümde 1 - 51 arası işlemleri seçerek toplu bir şekilde indirme işlemi sağlayabilirsiniz. "X" tuşu ile geri çıkabilirsiniz.
 
:: =============================================================================================================================================================================
::                                                                                    BONUS
:: =============================================================================================================================================================================
 • 53 - Bu bölüm işletim sistemine göre değişiklik göstermektedir. Windows 11 ve Windows 10 için iki ayrı bölüme ayrılmıştır.
 ---------------------------
 • 53 - Windows 10 Düzenleme
 ---------------------------
	• 1 - Saat yanı simgeler [GÖSTER/GİZLE]: 
		•[Göster]: 0 - Saat yanında yer alan tüm simgeleri gösterir.
		•[Gizle]: 1 - Saat yanında yer alan simgelerden ağ ve ses dışındaki simgeleri "▲" içine alır
		
	• 2 - Bildirim Alanı [Aç/Kapat]: 
		•[Aç]: 0 - Saat sağında yer alan bildirim alanını kapatır.
		•[Kapat]: 1 - Saat sağında yer alan bildirim alanını açar.
		
	• 3 - Sahiplik Al [Ekle/Kaldır]: Bazı sistem dosyalarında yetki sorunu yaşadığınızda imdadınıza yetişecek bölümdür.
		•[Ekle]: 1 - Sağ-tık bölümüne "Sahiplik Al" butonunu ekler.
		•[Kaldır]: 2 - Sağ-tık bölümünden "Sahipli Al" butonunu kaldırır.
		
	• 4 - Market [Yükle/Kaldır]:
		•[Kaldır]: 1 - Kaldırılabilir bütün market uygulamalarını siler.
		•[Yükle]: 2 - Market uygulamasını yeniden yükler.
		
	• 5 - CompactOS (Windows Sıkıştırma) [Aç/Kapat]: Windows sistem dosyalarını sıkıştırarak 3 - 4 GB'lık bir alan kazanmanızı sağlar. Performans kaybı yaratmaz.
		•[Aç]: 1 - Windows sistem dosyalarını sıkıştırmayı açar.
		•[Kapat]: 2 - Windows sistem dosyalarını sıkıştırmayı kapatır.
		
	• 6 - Gpedit.msc (Yerel Grup ilkesi) [Ekle]: Windows Home ve Home Single Language sürümlerine "Gpedit.msc" ekler.
	
	• 7 - Simgeleri Değiştir [Eski/Yeni]: 21H2 beta sürümünde gelen ancak iptal edilen simgeleri sisteme yükler. Bu bölüme ilk girişinizde simge dosyalarını indirecektir!
		•[Eski]: 1 - Windows 10 eski (Varsayılan) simgeleri yükler.
		•[Yeni]: 2 - Windows 10 yeni simgeleri yükler.

 ---------------------------
 • 53 - Windows 11 Düzenleme
 ---------------------------
	• 1 - Taskbar Boyut [Küçük/Orta/Büyük]: 
		•[Küçük]: 0 - Görev çubuğunu küçük yapar.
		•[Orta]: 1 - Görev çubuğunu varsayılan haline getirir.
		•[Büyük]: 2 - Görev çubuğunu büyük yapar.
		
	• 2 - Taskbar Konumu [Alt/Üst]: 
		•[Alt]: 1 - Görev çubuğunu alt bölüme alır.
		•[Üst]: 3 - Görev çubuğunu üst bölüme alır
		
	• 3 - Taskbar Simge Konumu [Sol/Orta]:
		•[Sol]: 0 - Görev çubuğundaki simgeleri sola dayar.
		•[Orta]: 1 - Görev çubuğundaki simgeleri ortalar. (Varsayılan)	
		
	• 4 - Sağ-tık Menü [Eski/Yeni]:
		•[Eski]: 1 - Sağ-tık menüsünü Windows 10'daki gibi yapar.
		•[Yeni]: 2 - Sağ-tık menüsünü Windows 11'deki gibi yapar. (Varsayılan)
		
	• 5 -Sağ-tık terminal [Ekle/Kaldır]:
		•[Kaldır]: 1 - Sağ-tık menüsünden terminal'i kaldırır.
		•[Ekle]: 2 - Sağ-tık menüsüne terminal ekler. (Varsayılan)
		
	• 6 - Sahiplik Al [Ekle/Kaldır]: Bazı sistem dosyalarında yetki sorunu yaşadığınızda imdadınıza yetişecek bölümdür.
		•[Ekle]: 1 - Sağ-tık bölümüne "Sahiplik Al" butonunu ekler.
		•[Kaldır]: 2 - Sağ-tık bölümünden "Sahipli Al" butonunu kaldırır.
	
	• 7 - CompactOS (Windows Sıkıştırma) [Aç/Kapat]: Windows sistem dosyalarını sıkıştırarak 3 - 4 GB'lık bir alan kazanmanızı sağlar. Performans kaybı yaratmaz.
		•[Aç]: 1 - Windows sistem dosyalarını sıkıştırmayı açar.
		•[Kapat]: 2 - Windows sistem dosyalarını sıkıştırmayı kapatır.
		
	• 8 - Gpedit.msc (Yerel Grup ilkesi) [Ekle]: Windows Home ve Home Single Language sürümlerine "Gpedit.msc" ekler.
	
:: =============================================================================================================================================================================
 ---------------------------------
 • 54 - Kapatılan Servisleri Yönet
 ---------------------------------
	• 1 - Bluetooth [Aç]: Bluetooth hizmetlerini açar.
	• 2 - Yazıcı [Aç]: Yazıcı hizmetlerini açar.
	• 3 - Telefon hizmetini [Aç]: Telefon uygulamasına ait hizmetleri açar.
	• 4 - Tarifeli ağları [Aç]: Kotalı internetiniz var, kota aşımını önlemek için bu hizmeti kullanabilirsiniz. (Nasıl oluyor hiç bilmiyorum, yalnızca hizmeti açıyorum :D)
	• 5 - IP Yardımcısı [Aç]: IPv6 destekli internet hizmetiniz var ise bu hizmeti açın.
	• 6 - Mobil Etkin Nokta (Hotspot) [Aç]: Kullandığınız cihazdan interneti paylaşmanızı sağlayayacak donanım var ise buradan hizmeti açabilirsiniz.
	• 7 - Radyo ve Uçak modu hizmeti [Aç]: Laptoplarda kullanılacak hizmettir. Windows 11'de bu hizmet kapalı olunca ağ simgesi görünmüyor. 
	• 8 - Akış deneyimi (Ekran Paylaş) [Aç]: Aynı ağı kullanan cihazları görmek ve ekrana yansıtma, aktarma gibi özellikleri kullanılabilmesi için hizmetleri açar.
	• 9 - Windows Şimdi Bağlan (WPS) [Aç]: WPS özelliğini kullanmanızı sağlayan hizmeti açar.
   • 10 - Tarayıcı hizmetlerini [Aç]: Tarayıcı cihazınızı sorunsuz kullanmanız için hizmetleri açar.
   • 11 - Kamera hizmetlerini [Aç]: Kamera cihazınızı sorunsuz kullanmanız için hizmetleri açar.
   • 12 - Uzak Masaüstü [Aç]: Uzak masaüstü hizmetlerini açar. Ağdaki cihazlar arası paylaşımda sıkıntı yaşıyorsanız 7 numaralı işlem ile birlikte açın.
   • 13 - Insider hizmeti [Aç]: Windows ön sürümlerini erkenden deneyimleyip hataları bulup bildirmek gibi bir koca yüreğiniz var ise bu servisi aktif ederek. Insider sürüme kayıt olunuz.
   • 14 - Biyometrik Hizmeti [Aç]: Kullanıdığınız cihazda parmak okuyucu tarzı cihazlar var ise sorunsuz kullanmanız için açar.
   • 15 - Kalem ve Dokunmatik Klavye hizmetini [Aç]: Dokunmatik destekli cihazınız var ise sorunsuz kullanmanız için hizmetleri açar.
   • 16 - Sistem geri yükleme hizmeti [Aç]: Sistem geri yükleme hizmetini açar.
   • 17 - Sysmain (Hızlı Getir) [Aç]: Windows daha hızlı deneyim sunması için diski daha fazla kullanır. Yüksek disk kullanımına sebebiyet verir. SSD varsa gereksizdir. Kullanırsanız hizmeti açar.
   • 18 - Hızlı Başlat (Hibernate) [Aç]: Sistem önbellekleme yaparak hızlı açılmasını sağlar. Ancak kapanmama gibi sorunlara neden olmaktadır. Kullanmak isterseniz hizmeti açar.
   • 19 - Konum hizmetini [Aç]: Bilgisayarlarda bu özelliği hep gereksiz bulmuşumdur. Laptop cihazınız konumunuzu tam olarak tespit edebiliyorsa açın. Yoksa hiç açmayın.
   • 20 - Windows Media Player [Aç]: Windows Media Player'ı yeniden açmanızı sağlar. 
:: ============================================================================================================================================================================= 
 ----------------------------
 • 55 - Simge Hatasını Düzelt: Simgeleri değiştirdikten sonra oluşacak sorunları giderir.
 ----------------------------
:: ============================================================================================================================================================================= 
 -------------------------
 • 56 - Windows Düzenleme:
 ------------------------- 
 Mavi renkli işlem numaraları 27 numaralı işlem ile alakalıdır.
 
	• 1 - WIM / ESD Okuyucu: install.wim ve install.esd dosyalarının içeriği hakkında bilgi verir.
		  • https://www.technopat.net/sosyal/konu/wim-ve-esd-dosyalarini-okumak.1672854/
	• 2 - AIO Windows Hazırla: İnstall.wim sürümlerini birleştirmeye yarar. "X" tuşu burada çalışmaz.
	• 3 - ISO Hazırla: Windows format dosyalarını ISO'ya dönüştürür. "Edit" klasörü içerisinde .iso dosyanızı bulabilirsiniz. "X" tuşu burada çalışmaz.
	• 4 - ESD to WIM [Dönüştür]: install.esd dosyalarını install.wim olarak dönüştürür. Çoklu seçim yapılabilir. Çoklu seçimlerde seçim arasına virgül koyun. "Örnek; 1,2,3,4" 
	• 5 - WIM /Delete: install.wim içinde yer alan istemediğiniz sürümleri silebilirsiniz. Çoklu seçim imkanı yoktur.
	• 6 - WIM Mount: install.wim dosyasını klasöre çıkarır.
	• 7 - WIM Remount: Mount edilen dosya toplanmadan bilgisayar resetlenirse klasörü toparlamak veya işlem yapmak için yeniden yüklenmesi gerekir.
	• 8 - WIM Unmount: Mount edilen dosyaları toplar
	• 9 - Regedit [Yükle]: Offline sistemin regedit kayıtlarını online sisteme entegre ederek değişim yapmanızı sağlar. Detaylı bir konudur. Bu konularda tecrübeniz yoksa bulaşmayın.
		  • Bu bölümü kullanmadan önce sistemi farklı bir program ile mount ettiyseniz programı kapatın. Yoksa hata alırsınız.
		  • Offline sisteme eklenilen regedit kayıtları online sistemden farklı tepkiler verecektir. Lütfen bu durumu göz önünde bulundurun.
		  • -------------------------------------------------------------------------------
		  •                 Varsayılan Yol       Entegre edilmiş hali
		  •                ---------------       --------------------
		  •                 [HKLM\SOFTWARE]  ► ► [HKLM\OG_SOFTWARE]
		  •                          [HKCR]  ► ► [HKLM\OG_SOFTWARE\Classes]
		  •                   [HKLM\SYSTEM]  ► ► [HKLM\OG_SYSTEM]
		  •                          [HKCU]  ► ► [HKLM\OG_NTUSER]
		  •                  [HKU\.Default]  ► ► [HKLM\OG_DEFAULT]
		  • [HKLM\SYSTEM\CurrentControlSet]  ► ► [HKLM\OG_SYSTEM\ControlSet001]
		  • -------------------------------------------------------------------------------
		  • ► Örnek 1:
		  • ----------
		  • [Varsayılan Yol]: reg add "HKLM\SOFTWARE\Microsoft\Speech_OneCore\Preferences" /v "ModelDownloadAllowed" /t REG_DWORD /d 0 /f
		  • [Entegre edilmiş hali]: reg add "HKLM\OG_SOFTWARE\Microsoft\Speech_OneCore\Preferences" /v "ModelDownloadAllowed" /t REG_DWORD /d 0 /f
		  • ----------
		  • ► Örnek 2:
		  • ----------
		  • [Varsayılan Yol]: Reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" /v "EnableWebContentEvaluation" /t REG_DWORD /d 0 /f
		  • [Entegre edilmiş hali]: Reg add "HKLM\OG_NTUSER\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" /v "EnableWebContentEvaluation" /t REG_DWORD /d 0 /f
		  • ----------
		  • ► Örnek 3:
		  • ----------
		  • [Varsayılan Yol]: Reg add "HKU\.Default\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" /v "PreventOverride" /t REG_DWORD /d 0 /f
		  • [Entegre edilmiş hali]: Reg add "HKLM\OG_DEFAULT\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" /v "PreventOverride" /t REG_DWORD /d 0 /f
		  • ----------
		  • ► Örnek 4:
		  • ----------
		  • [Varsayılan Yol]: reg add "HKCR\*\shell\runas" /ve /t REG_SZ /d "Sahipliği Al" /f 
		  • [Entegre edilmiş hali]: reg add "HKLM\OG_SOFTWARE\Classes\*\shell\runas" /ve /t REG_SZ /d "Sahipliği Al" /f 
		  • ----------
		  • ► Örnek 5:
		  • ----------
		  • [Varsayılan Yol]: "HKLM\SYSTEM\CurrentControlSet\Control\FileSystem" /v "LongPathsEnabled" /t REG_DWORD /d 1 /f
		  • [Entegre edilmiş hali]: "HKLM\OG_SYSTEM\ControlSet001\Control\FileSystem" /v "LongPathsEnabled" /t REG_DWORD /d 1 /f
		  • ------------------------------------------------------------------------------- 
   • 10 - Regedit [Topla]: Yüklenilen regedit kayıtlarını toplar. Regedit kayıtlarını yüklerseniz toplamayı unutmayın. Yoksa diğer programlarda hata alırsınız.
   • 11 - Win10 Hazır Regedit Kayıtları: Windows 10 için hazırladığım hazır reg kayıtlarıdır. Offline sisteme entegre edilir.
   • 12 - Win11 Hazır Regedit Kayıtları: Windows 11 için hazırladığım hazır reg kayıtlarıdır. Offline sisteme entegre edilir.
   • 13 - Dism Update [Online]: Windows update dosyalarını yüklü sisteme yükler. Update dosyalarını "Edit\Update" içine atınız.
   • 14 - Dism Update [Offline]: Windows update dosyalarını offline sisteme yükler. Update dosyalarını "Edit\Update" içine atınız.
		  • Dism ile detaylı bilgi için; https://www.technopat.net/sosyal/konu/dism-ile-offline-online-guencelleme-entegrasyonu.1671141/
		  • Sisteme güncelleme kurmak için Microsoft Update Catalog sitesinden Windows sürümünüzü yazarak arama yapın.
		  • Çıkan arama sonuçlarında "Cumulative" yazan son güncelleştirmeyi indirip yükleyin. Önceki sürümleri de kapsamaktadır. 
		  • Güncelleme dosyalarını indirmek için: https://www.catalog.update.microsoft.com/
   • 15 - Appx Yükleyici [Offline]: Market uygulama paketlerini offline sisteme yükler. Yükleme dosyalarını "Edit\Appx" içine atınız
   • 16 - Appx Yükleyici [Online]: Market uygulama paketlerini online sisteme yükler. Yükleme dosyalarını "Edit\Appx" içine atınız
		  • Appx dosyalarının indirmek için: https://store.rg-adguard.net/
		  • Detaylı bilgi için: https://www.technopat.net/sosyal/konu/powershell-appx-komutlarinin-kullanimi.1684246/
   • 17 - Driver Yedekle [Online]: Yüklü sistemden Driverları yedekler. Yedeklediği konum "Edit\Driver\Yedek"
   • 18 - Driver Yedekle [Offline]: Offline sisteme driver entegre eder. Driver dosyalarını "Edit\Driver" klasörü içine atın. Yedek aldıktan sonra bu bölümü seçerseniz, yedekleri imaja yükler.
   • 19 - Setup Düzenle [Offline]: Windows yükleme dosyalarını özelleştirir. İlk girişte "Files\setup10.zip" dosyasını indirir. Kendinize özel bölüm oluşturmak istiyorsanız. Aşağıdaki linke bakınız.
		  • https://www.technopat.net/sosyal/konu/ntlite-ile-windows-10-setup-duezenleme.1355403/
   • 20 - Yeni simgeleri yükle [Offline]: Yeni simgeleri imaja entegre eder. İlk girişte "Files\Newico.zip" dosyasını indirir. 
   • 21 - Walpaper değiştir [Offline]: Varsayılan duvar kağıtlarını değiştirir. Seçtiğiniz resimleri yüklemek istiyorsanız "Files\Walpaper.zip" dosyasını düzenleyin.
   • 22 - Telemetri engelle (Host) [Offline]: Offline sistemden hosts dosyasını değiştirir içerisinde telemetri servislerini engelleyen parametreler vardır.
   • 23 - OneDrive Sil [Offline]: Offline sistemden OneDrive siler.
   • 24 - Gpedit.msc ekle [Offline]: Offline sistemden Windows Home ve Home Single Language sürümlerine ekleyebilirsiniz.
:: ------------------------------------------------------------------------------------------------------------------------------
   • 25 - Katılımsız program ve ayar ekle [Offline]: Offline sisteme katılımsız program entegre eder.
		  • 51 numaralı işlem [Çoklu Seçim] bölümü 1 - 50 işlemlerini kapsamaktadır.
   • 26 - Katılımsız program ve ayar ekle [Online]: Offline sisteme indir, kur, sil olarak program entegre eder.
		  • Yazacaklarım 25 ve 26. bölümleri kapsamaktadır.
		  • Bu bölümde program eklemek isterseniz öncelikle 53 numaralı işlemi [Katılımsız kurulum dosyası oluştur] uygulayın. Ondan sonra dilediğinizi ekleyin.
		  • Program ve ayar ekleme işlemi bittikten sonra 54 numaralı işlemi [Katılımsız kurulum dosyasını tamamla] uygulayın. 
		  • 54 numaralı işlemi uyguladıktan sonra yedek almak isterseniz. 98 numaralı işlemi [Katılımsız Yedekle] uygulayın. Yedek dosyasını masaüstüne atacaktır.
		  • 99 numaralı işlem [Yedekten ekle] ile yedeklediğiniz .zip dosyasının yolunu tanımlayarak offline sisteme entegre edebilirsiniz.
		  • Offline ve online bölümleri aynı anda kullanabilirsiniz. Ancak bu tarz bir durumda 53 numaralı işlemi [Online] bölümünden uygulayın.
		  • Online bölümü ekleme işleminde indirme olmadığı için çoklu seçim bölümü yoktur.
:: ------------------------------------------------------------------------------------------------------------------------------	
	• 27 - Mount yol tanımla: Bu bölüm 9 - 11 - 12 - 14 - 15 - 18 - 20 - 21	- 22 - 23 - 24 - 25 - 26 bölümlerle bağlantılıdır. 
		   • Burada tanımlanan klasör yolu ile işlem yapılmaktadır.
		   • Bu bölüm ilk girişte "Edit\Mount" klasör yolunu alır. Mount dosyaları farklı bir klasörde ise 27 numaralı işlem ile değiştirin.
:: ============================================================================================================================================================================= 	  
 -----------------------------------
 • 57 - Güncelleme Sonrası Temizlik: Güncelleme sonrası yüklenen Defender, Telemetri, Diagtrack gibi hizmetleri yeniden kapatır.
 ---------------------------- 	
 • 58 - Sistem / Market Onar: Microsoft'un önerdiği bütün onarma seçeneklerini uygular.
 ------------------
 • 59 - PC Temizle: Sistemde biriken çöp dosyaları temizler.
 --------------------- 
 • 60 - Appx Yönetici: Windows App Boss uygulamasını açar. Sistemde yüklü olan market uygulamalarını kaldırabilirsiniz. Kaldırılamayan uygulamaları silemez.
	    • Resmi sayfası: https://github.com/jason-grimme/WindowsAppBoss
 ---------------------
 • 61 - Folder to ISO: Folder to ISO uygulamasını açar. Klasör içindeki verileri ISO dosyasını çevirir.
	    • Resmi sayfası: https://www.trustfm.net/software/utilities/Folder2Iso.php
 --------------------- 
 • 62 - Fat32 to NTFS: Fat32 olarak formatlanmış USB diskleri veri kaybı olmadan NTFS'ye çevirir. Disk harfini girmeniz gerekmektedir.
 ------------------
 • 63 - Ping Ölçer: İçerisinde belirli sitelerin ping durumlarını otomatik gösterir. Alt bölümde yer alan "Ping ölç" bölümüyle istediğiniz site ve IP'nin pingini ölçebilirsiniz.
 ------------------ 
:: ============================================================================================================================================================================= 
 ----------------------- 
 • 64 - Lisans Yönetimi: SLMGR.VBS komutlarını içermektedir. Crack tarzı işlemler bulunmamaktadır. 
 ----------------------- 
	• 1 - Lisans Gir [ipk]: Lisans numaranızı girerek sistemi lisanslayabilirsiniz.
	• 2 - Lisans Durumu [dli]: Lisans durumu hakkında bilgi verir.
	• 3 - Lisans Durumu Detaylı [dlv]: Lisans durumu hakkında detaylı bilgi verir.
	• 4 - Lisans Süresini Öğren [xpr]: Lisans süresi hakkında detaylı bilgi verir.
	• 5 - Lisans Sil [upk]: Sistem kullandığınız lisansı siler.
	• 6 - Lisans Süre Sıfırla [rearm]: Windows 30 günlük deneme sürümü süresini 3 defa uzatabilirsiniz. 
:: ============================================================================================================================================================================= 
 ------------------------------- 
 • 65 - Kullancı Hesap Yönetimi: 
 -------------------------------  
	• 1 - Administrator [AKTİF]: Administrator hesabını açar.
	• 2 - Administrator [PASİF]: Administrator hesabını kapatır.
	• 3 - Admin grubuna Kullanıcı ekle: Admin grubuna kullanıcı eklersiniz.
	• 4 - Kullanıcı [EKLE]: Yeni kullanıcı oluşturabilirsiniz.
	• 5 - Kullanıcı [SİL]: Mevcut bir kullanıcıyı silebilirsiniz.
	• 6 - Şifremi unuttum: Şifre değiştirmek veya şifre oluşturmak için bu bölüm kullanılabilir.
	• 7 - Mevcut Kullanıcıları Göster: Sistemde kayıtlı kullanıcıları gösterir.
:: ============================================================================================================================================================================= 
 ----------------------- 
 • 66 - Sistem Hakkında: Sistem ve donanım hakkında bilgi verir.
 ----------------------
 • 97 - Toolbox Rehber: Toolbox kullanımı hakkında tüm bilgileri verir
 ----------------------
 • 98 - Toolbox Güncelle: Toolbox sürümünüzü buradan tek tıkla güncelleyebilirsiniz. Toolbox konumunu değiştirdiyseniz yeniden "C:\OgnitorenKs.Toolbox" klasörüne kuracaktır.
 ---------------------  
 • 99 - Sürüm Notları: Toolbox sürümleri hakkında bilgi alabilirsiniz. Yeni bir sürüm çıkıp çıkmadığını buradan öğrenebilirsiniz.
 ---------------------  
:: ============================================================================================================================================================================= 

:: ==============================================================================================================================
::
::       ■■■■■■■   ■■■■■■   ■■    ■■ ■■■■ ■■■■■■■■  ■■■■■■■  ■■■■■■■■  ■■■■■■■■ ■■    ■■ ■■    ■■  ■■■■■■
::      ■■     ■■ ■■    ■■  ■■■   ■■  ■■     ■■    ■■     ■■ ■■     ■■ ■■       ■■■   ■■ ■■   ■■  ■■    ■
::      ■■     ■■ ■■        ■■■■  ■■  ■■     ■■    ■■     ■■ ■■     ■■ ■■       ■■■■  ■■ ■■  ■■   ■■
::      ■■     ■■ ■■   ■■■■ ■■ ■■ ■■  ■■     ■■    ■■     ■■ ■■■■■■■■  ■■■■■■   ■■ ■■ ■■ ■■■■■      ■■■■■■ 
::      ■■     ■■ ■■    ■■  ■■  ■■■■  ■■     ■■    ■■     ■■ ■■   ■■   ■■       ■■  ■■■■ ■■  ■■         ■■
::      ■■     ■■ ■■    ■■  ■■   ■■■  ■■     ■■    ■■     ■■ ■■    ■■  ■■       ■■   ■■■ ■■   ■■  ■■    ■■
::       ■■■■■■■   ■■■■■■   ■■    ■■ ■■■■    ■■     ■■■■■■■  ■■     ■■ ■■■■■■■■ ■■    ■■ ■■    ■■  ■■■■■■ 
:: ==============================================================================================================================
