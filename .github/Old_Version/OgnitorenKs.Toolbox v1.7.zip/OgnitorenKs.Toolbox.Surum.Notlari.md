:: ==============================================================================================================================
::
::       ■■■■■■■   ■■■■■■   ■■    ■■ ■■■■ ■■■■■■■■  ■■■■■■■  ■■■■■■■■  ■■■■■■■■ ■■    ■■ ■■    ■■  ■■■■■■
::      ■■     ■■ ■■    ■■  ■■■   ■■  ■■     ■■    ■■     ■■ ■■     ■■ ■■       ■■■   ■■ ■■   ■■  ■■    ■
::      ■■     ■■ ■■        ■■■■  ■■  ■■     ■■    ■■     ■■ ■■     ■■ ■■       ■■■■  ■■ ■■  ■■   ■■
::      ■■     ■■ ■■   ■■■■ ■■ ■■ ■■  ■■     ■■    ■■     ■■ ■■■■■■■■  ■■■■■■   ■■ ■■ ■■ ■■■■■      ■■■■■■ 
::      ■■     ■■ ■■    ■■  ■■  ■■■■  ■■     ■■    ■■     ■■ ■■   ■■   ■■       ■■  ■■■■ ■■  ■■         ■■
::      ■■     ■■ ■■    ■■  ■■   ■■■  ■■     ■■    ■■     ■■ ■■    ■■  ■■       ■■   ■■■ ■■   ■■  ■■    ■■
::       ■■■■■■■   ■■■■■■   ■■    ■■ ■■■■    ■■     ■■■■■■■  ■■     ■■ ■■■■■■■■ ■■    ■■ ■■    ■■  ■■■■■■ 
::
::  Hazırlayan: Hüseyin UZUNYAYLA / OgnitorenKs
::  Toolbox'ı hazırladığım sistemlerde temel programları indirip, basit bir şekilde sistem üzerinde düzenleme yapması için hazırladım.
::  Sürekli olarak güncellenecektir. Toolbox'ı indirmek için aşağıdaki linkleri kullanabilirsiniz.
::  ► https://www.technopat.net/sosyal/konu/ognitorenks-toolbox-kullanimi.1790250/
::
::  OgnitorenKs.Toolbox katılımsız kurulum dosyasını indirmek için aşağıdaki "Toolbox.Update.bat" dosyasını indirip yönetici olarak çalıştırın.
::  ► https://docs.google.com/uc?export=download&id=1JmrWYeNjVopcIP0n9iNkMUCEbQ2SIvpY
::
::  İstek ve önerileriniz olursa, iletişim;
::  ► Discord: OgnitorenKs#2737 
::  ► Mail: ognitorenks@gmail.com
::  ► Site: ognitorenks.blogspot.com (Bu bölüm şu an aktif değil)
::  ► Site: www.technopat.net\Sosyal (Yeni bir konu açıp yada hazırladığım konularda @OgnitorenKs yazarak etiketleyebilirsiniz) 
:: ==============================================================================================================================
::  PROJEYE KATKIDA BULUNANLAR;
::  ---------------------------
::  ► Eray Türkay [470650]
::  ----------------------
::    • Sistem Hakkında - RAM soket yapısının eklenmesi.
::    •	Sistem Hakkında - Sistem format tarihinin eklenmesi.
::  ----------------------
::  ► KaanBeyhan [DOGGEST]
::  ----------------------
::    • İndirme işlemlerinde ilerleme çubuğunun eklenmesi.
::
:: ==============================================================================================================================
-----------------
 ► Versiyon 1.7 -
-----------------
Yayınlanma Tarihi: 01.01.2022
 
 • Toolbox Kullanım.md dosyası hazırlandı. (Toolbox'ın kullanımıyla ilgili tüm detaylar içinde yer almaktadır.)
 • Tekli bilgi mesajları menüden görüntelenecek şekilde düzenlendi.
 • Ana menüdeki geri dönüş sonrası yaşanan sorun düzeltildi.
 • Regedit yükleme bölümüne dosya kontrol sistemi getirildi.
 • Windows Düzenleme > "Setup Düzenleme" bölümündeki kodlar düzenlendi.
 • Windows Düzenleme > "Hızlı başlatma" bölümündeki kod hatası giderildi.
 • Lisans Yönetimi bölümündeki hatalar giderildi.
 • Bazı bölümlerdeki log oluşturamama sorunu giderildi.
 • Windows 10/11 Edit bölümünde bazı bölümlerden geri döndükten sonra işletim sistemi bilgisinin bozulma sorunu giderildi.
 • Windows Düzenleme > WIM Mount, Remount, Unmount, Setup Düzenleme, bölümlerindeki işlemleri Dism ile uygulanacak şekilde düzenlendi. İmagex komutları kaldırıldı.
 • Windows Düzenleme > "WIM Unmount" bölümüne bilgi ekranı eklendi.
 • Windows Düzenleme > AIO Windows Hazırla, ESD to WIM bölümlerinde "X" tuşu ile geri çıkma işlemi iptal edildi. Bazı durumlarda hataya neden oluyordu.
 • Kapatılan Servisler bölümü > Media player yönlendirme hatası giderildi.
 • Notepad++ indirme linki yenilendi. (8.1.9.3 > 8.2)
 • TaskbarX indirme linki yenilendi. (1.7.4.0 > 1.7.6.0)

:: ==============================================================================================================================
-----------------
 ► Versiyon 1.6 -
-----------------
Yayınlanma Tarihi: 29.12.2021

 • Windows Düzenleme > "Wim /Delete" çoklu seçme özelliği kaldırıldı. (İndex numaraları kaydığı için ilk silme işleminden sonra hatalı işlem yapıyordu)
 • Windows Düzenleme > Yol tanımlama bölümlerinde gereksiz komutlar kaldırıldı.
 • Windows Düzenleme > "AIO Windows Hazırla" çoklu seçme özelliğindeki hata giderildi.
 • Windows Düzenleme > Tüm bölümlerde "X" tuşu geri dönüş tuşu olarak ayarlandı.
 • Windows Düzenleme > "AIO Windows Hazırla" birleştirme bölümündeki eski tema sorunu giderildi.
 • Windows Düzenleme > "Telemetry engelle (Hosts)" bölümündeki yönlendirme hatası giderildi."
 • Sistem Hakkında > Sistem format tarihi eklendi. [Eray Türkay'a verdiği bilgi için teşekkür ederim]
 • Olası sorunlarda hızlı hata tespiti için log sistemi eklendi.
 • İndirme işlemlerinde internet durum kontrolü eklendi.
 • Toolbox.bat içinde yorum satırları arttırıldı. 
 
:: ==============================================================================================================================
-----------------
 ► Versiyon 1.5 -
-----------------
Yayınlanma Tarihi: 27 Aralık 2021

 • Windows Düzenleme > ISO hazırlama bölümüne etiket ve ISO isim verme özelliği eklendi.
 • Setup düzenleme bölümünde duraklamaya neden olan komut kaldırıldı.
 • WIM Mount bölümüne boot.wim çıkarma desteği eklendi. 
 • Kullanıcı hesap yönetimi bölümünde iç bölümlere X tuşu menüye dönüş olarak ayarlandı.
 • Sistem hakkında bölümünde Ram kısmına Soket yapısı eklendi. [Eray Türkay'a verdiği bilgi için teşekkür ederim]
 • İndirme işlemlerinde ilerleme çubuğu eklendi. [KaanBeyhan'a (DOGGEST) verdiği bilgi için teşekkür ederim]
 • TaskbarX indirme linki yenilendi. (1.7.3.0 > 1.7.4.0)

:: ==============================================================================================================================
-----------------
 ► Versiyon 1.4 -
-----------------
Yayınlanma Tarihi: 23 Aralık 2021

 • OgnitorenKs Toolbox Update aracına internet ve toolbox dosya kontrol sistemi getitirildi.
 • Windows edit bölümünde bazı bölümlerde yer alan buglar giderildi.
 • Katılımsız kurulum dosya hazırlama bölümünde düzenlemeler yapıldı. 
   • Online bölümüne internet bağlantı kontrol bölümü eklendi.
 • Windows 10 Edit bölümüne "Eski ve Yeni simgelere geçiş bölümü eklendi"
 • Signal indirme linki yenilendi. (5.26.0 > 5.26.1)
 • Kdenlive indirme linki yenilendi. (21.08.3 > 21.12.0)
 • Krita indirme linki yenilendi. (4.4.8 > 5.0.0)
 • Gimp indirme linki yenilendi. (2.10.28 > 2.10.30)
 • Audacity indirme linki yenilendi. (3.1.2 > 3.1.3)
 
:: ==============================================================================================================================
-----------------
 ► Versiyon 1.3 -
-----------------
Yayınlanma Tarihi: 22 Aralık 2021

 • İndirmeye devam et özelliği eklendi.
   • Bu özellik ile indirilmiş olan dosyalar tekrar indirilmeyecek. 
   • Herhangi bir sebepten ötürü Toolbox kapanırsa işlem tekrar edildiğin kaldığı yerden indirmeye devam edecektir.
 • Windows 10-11 Edit bölümleri işletim sistemine göre gösterilecektir. Windows 10'da 11'i | Windows 11'de 10 için ayrılan bölüm görünmeyecektir.
   • Home ve Home Single Language sistemlerde Gpedit.msc aktifleştirmek için ayar eklendi.
 • Terminal bölümündeki yönlendirme hatası giderildi.
 • Tema değiştirildi.
 • Sistem hakkında bölümünde Disk yapısını hatalı gösteren komut hatası giderildi.
 • Sistem - Market onar bölümünde düzenlemeler yapıldı. 
 • Ana ekran bilgi ekranına ve Sistem Hakkında bölümüne derleme numarası dahil edilmiştir. 
   • Derleme numarası (10.0.19043. ► 1348 ◄) Ok işaretleriyle gösterdiğim kısımdır. 
 • Katılımsız güncelleştirme aracının komutlarında düzenleme yapıldı.
 • Cheat Engine / Origin / Chrome bölümündeki kod hatası giderildi.
 • Toolbox içindeki tüm linkler "Ekler" klasöründe Links.bat içinde toplanmıştır.
 • Format Factory uygulaması sessiz kurulum işlemine imkan vermediği için kaldırıldı.
   • Any Video Converter uygulaması eklendi.
 • LightShoot uygulaması kaldırıldı. Offical sitesine Captcha doğrulaması geldiği için indirme yapılamıyor.
   •ShareX yazılımı eklendi. Her açıdan LightShoot uygulamasından çok daha iyi.	
 • Eagle Get uygulaması kaldırıldı. Program yapımcıları resmi siteyi kapatıp. Programı güncellemeyi bıraktılar.
 • OpenShell indirme linki güncellendi.
 • Edge indirme linki güncellendi.
 • ISLC programı eklendi.
 • Everything indirme linki yenilendi. (1.4.1.1009 > 1.4.1.1015)
 • Cheat Engine indirme linki yenilendi. (7.2 > 7.3)
 • Hibit Uninstaller indirme linki yenilendi. (2.7.10 > 2.7.15)
 • K-Lite Codec indirme linki yenilendi. (16.6.0 > 16.6.5)
 • 7 - Zip indirme linki yenilendi. (7.21.3 > 7.21.6)
 • Notepad++ indirme linki yenilendi. (8.1.9.2 > 8.1.9.3)
 • Libre Office indirme linki yenilendi. (7.2.2 > 7.2.4)
 • Signal indirme linki yenilendi. (5.25.0 > 5.26.0)
 • Windows 10 Market yükle bölümündeki kod hatası giderildi.
 • Kapatılan servisleri yönet bölümü eklendi.
 • Adobe Reader yazılımı yerine PDF-XChange Editör yazılımı eklenmiştir. Ücretsiz ve daha faydalı bulduğum için değiştirdim.  
 • Windows Edition bölümü eklendi. İçerisinde;
   • WIM / ESD Okuyucu eklendi 
   • AIO Windows Hazırla eklendi.
   • ISO Hazırla eklendi.
   • ESD to WIM / Çıkart eklendi.
   • WIM /Delete eklendi.
   • WIM [Yükle] eklendi.
   • WIM [Topla] eklendi.
   • Regedit [Yükle] eklendi.
   • Regedit [Topla] eklendi.
   • Dism Update [Online] eklendi.
   • Dism Update [Offline] eklendi.
   • Appx yükleyici [Offline] eklendi.
   • Appx yükleyici [Online] eklendi.
   • Driver Yedekle [Online] eklendi.
   • Driver yükle [Offline] eklendi.
   • Setup Düzenle [Offline] eklendi.
   • Yeni Simgeleri yükle[Offline] eklendi.
   • ISLC Ekle[Offline] eklendi.
   • Masaüstüne dosya ekle[Offline] eklendi.
   • OgnitorenKs.Toolbox ekle[Offline] eklendi.
 • Windows Düzenle bölümüne eklediğim aşağıdaki 2 bölüm ile sisteme katılımsız şekilde Toolbox'taki programlar dahil edilebilecek.
 • Online bölümündeki linkler oto link güncelleme sistemiyle sürekli güncel kalması için düzenleme yapılmıştır. 
 • Katılımsız program ve ayar ekle[Offline] eklendi.
 • Katılımsız program ve ayar ekle[Online] eklendi.


:: ==============================================================================================================================
-----------------
 ► Versiyon 1.2 -
-----------------
Yayınlanma Tarihi: 3 Aralık 2021

 • "Sahiplik al" ekleme bölümündeki kod hatası giderildi.
 • Hibit Uninstaller indirme linki yenilendi. (2.6.25 > 2.7.10)
 • Signal indirme linki yenilendi. (5.24.0 > 5.25.0)
 • Kdenlive indirme linki yenilendi. (21.08.2 > 21.08.3)
 • K-Lite Codec indirme linki yenilendi. (16.5.3 > 16.6.0)
 • NET Desktop Runtime indirme linki yenilendi. (5.0.11 > 5.0.12)
 • "Kapatılan Servisler Yönetim" bölümünde düzenlemeler yapıldı.
 • Fat32toNTFS bölümü işlemleri ana ekrandan yürütülecek şekilde düzenlendi.
 • Format Factory kurulum hatası giderildi.
 • Katılımsız güncelleştirme sistemi eklenmiştir.
   • OgnitorenKs.Toolbox klasörü içerisinde yer alan Toolbox.Update.bat dosyasını çalıştırarak güncelleme işlemini yapabilirsiniz.

:: ==============================================================================================================================
-----------------
 ► Versiyon 1.1 -
-----------------
Yayınlanma Tarihi: 26 Kasım 2021

 • Sunduğum diğer sistemlerde kapattığım bazı hizmetlerin yeniden açılması için Windows 10 ve Windows 11 edit bölümlerine eklemeler yaptım.
   • Bu bölüm ilk sürümde yer alan "Laptop hizmetlerini aç" "Yazıcı aktifleştir" bölümlerini de kapsamaktadır.
   • Servisleri toplu olarak açmak yerine ihtiyaç durumuna göre tek tek açılması üzerine düzenledim.
 • Olası ICO sorunu için hazırladığım IcoFix Toolbox'a entegre edildi.  
 • Skype kurulumunda x64 hatası verdiği için kaldırıldı.
   • Skype uygulamasının yerine Zoom uygulaması eklenmiştir. 
 • Blitz uygulamasındaki kurulum hatası giderildi.
 • Signal indirme linki güncellendi.(5.20 ► 5.24)
 • Audacity indirme linki güncellendi. (3.0.5 ► 3.1.2)
 • K-Lite Codec indirme linki güncellendi. (16.5.0 ► 16.5.3)
 • Format Factory indirme linki güncellendi. (5.8.1 ► 5.9.0)
   • Format Factory katılımsız kurulmamaktadır. Kurulum işlemlerinin manuel ilerletilmesi gerekmektedir.
   • Kurulumda dikkat edin farklı programlar kurdurmaya çalışmakta o seçenekleri kabul etmeyin.
   • Sonraki sürümlerde oto kurulum yapması için script hazırlayacağım.
 • TaskbarX indirme linki güncllendi. (1.7.2.0 ► 1.7.3.0)
 • SSDFresh uygulaması sistemsel bir arızaya neden olduğu için kaldırıldı
   • Alternatif olarak SSDBooster yazılımı eklendi. Portable bir yazılımdır ve masaüstüne indirilmektedir.
 • Sürüm notları Toolbox içine kısayol olarak eklendi.
 :: ==============================================================================================================================

 -----------------
 ► Versiyon 1.0 -
-----------------
Yayınlanma Tarihi: 23 Kasım 2021

 :: ==============================================================================================================================