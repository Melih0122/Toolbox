::
::       ██████   ██████   ██    ██ ████ ████████  ██████  ████████  ████████ ██    ██ ██    ██  ██████
::      ██    ██ ██    ██  ███   ██  ██     ██    ██    ██ ██     ██ ██       ███   ██ ██   ██  ██    █
::      ██    ██ ██        ████  ██  ██     ██    ██    ██ ██     ██ ██       ████  ██ ██  ██   ██
::      ██    ██ ██   ████ ██ ██ ██  ██     ██    ██    ██ ████████  ██████   ██ ██ ██ █████      ██████ 
::      ██    ██ ██    ██  ██  ████  ██     ██    ██    ██ ██   ██   ██       ██  ████ ██  ██         ██
::      ██    ██ ██    ██  ██   ███  ██     ██    ██    ██ ██    ██  ██       ██   ███ ██   ██  ██    ██
::       ██████   ██████   ██    ██ ████    ██     ██████  ██     ██ ████████ ██    ██ ██    ██  ██████ 
::
::                    ████████ ███████ ███████ ██      ██████  ███████  ██    ██
::                       ██    ██   ██ ██   ██ ██      ██   ██ ██   ██   ██  ██  
::                       ██    ██   ██ ██   ██ ██      ██████  ██   ██     ██   
::                       ██    ██   ██ ██   ██ ██      ██   ██ ██   ██   ██  ██
::                       ██    ███████ ███████ ███████ ██████  ███████  ██    ██
::
::  Hazırlayan: Hüseyin UZUNYAYLA / OgnitorenKs
::
::  İletişim - Contact;
::  --------------------------------------
::  • Discord: OgnitorenKs#2737 
::  •    Mail: ognitorenks@gmail.com
::  •    Site: https://ognitorenks.blogspot.com/
::
-----------------
 ► Versiyon 3.0 -
-----------------
Yayınlanma Tarihi:

 • 'Update.ini' dosyası 'Settings.ini' olarak değiştirildi.
 • Admin yetkili girişi manuel ve otomatik olarak ayarlanması için Settings.ini dosyasına yönetim bölümü eklendi.
 • 'Logss' fonksiyonu 'LogSave' olarak değiştirildi.
 • Gereksiz komutlar ayıklandı.
 • Toolbox karekter takımı 'UTF-8' ile yeniden düzenlendi.
 • İndirme komutları optimize edildi.
 • 'Icon Fix' ve 'PC Temizle' seçenekleri kaldırıldı.
   • İçerisinde yer alan sistem onarma komutları 'Windows - Market onar' bölümüne ilave edildi.
 • iTunes indirme bölümüne eklendi.
 • Motrix indirme bölümüne eklendi.
 • Google Chrome / Brave / Edge tarayıcı eklentileri Settings.ini dosyasına eklendi. 
   • Bu bölüme ekleme yapıp çıkarabilirsiniz. Dilerseniz eklentilerin yüklenmesini devre dışı bırakabilirsiniz.
 • İnternet kontrolü için yönlendirme sitesi www.bing.com olarak ayarlandı.
 • İndirme bölümü ayrı bir menü haline getirilip, programlar gruplandırıldı.
 • Ana menü tasarımı tamamen değiştirildi.
 • Windows Editör bölümünden Appx ve Dism Update seçenekleri birleştirilerek ana menüye eklendi.
 • PowerChoice Toolbox içine 'Güç Seçenekleri' olarak eklendi. Dileyenler masaüstündeki kısayolunu silebilir.
 • Toolbox Ayarlar bölümü oluşturuldu. Buradan Toolbox üzerinde bazı özellikleri değiştirebilirsiniz.
 • Log kayıt sistemi geliştirildi. Mevcut hatalar giderildi.
 • PowerRun yazılımı yerine NSudo eklendi.
 • İşlem tamamlandı ekranı oluşturuldu. [Archley'e desteği için teşekkür ederim.]
 • Otomatik güncelleme sistemi yeni güncellemeyi tespit ettiğinde sürümler hakkında bilgi vererek işleme devam edecek şekilde düzenlendi.
 • OgnitorenKs Toolbox kısayol simgesi yönetici çalışacak şekilde ayarlandı. [Finch'e desteği için teşekkür ederim]
 • Windows Editör > Genel bir optimizasyon çalışması yapıldı. Gereksiz komutlar kaldırılıp daha düzenli hale getirildi.
 • Windows Editör > İmaj toplama bölümündeki Dism komutu Powershell komutuyla değiştirildi.

-----------------
 ► Versiyon 2.9 -
-----------------
Yayınlanma Tarihi: 26.04.2022

 • Hizmetler Yönetimi > Dokunmatik servis bölümünde Windows 10 / 11 için ayrı servis bölümleri oluşturuldu.
 • Hizmetler Yönetimi > Hizmetlerin durumu hakkında bilgi alırken olası hata mesajlarının engellenmesi için yeni parametreler eklendi.
 • Simge önbelleğini temizle bölümünde hatalı komutlar düzeltildi.
 • Otomatik güncelleme sistemi düzenlendi. Güncelleştirme işlemi gün içinde tek bir kez kontrol edilecek şekilde düzenlendi.
 • Any Video Converter yazılımı kaldırıldı.
   • [YMuratK] tavsiyesiyle FileConverter programı eklendi.
 • Toolbox İngilizce > Hizmetleri yönet bölümündeki dil hatası giderildi.

:: ==============================================================================================================================

-----------------
 ► Versiyon 2.8 -
-----------------
Yayınlanma Tarihi: 21.04.2022

 • Icon fix bölümüne yeni parametreler eklendi.
 • Icon fix bölümü "Simge Önbelleğini Temizle" olarak değiştirildi.
 • Hizmet Yönetimi > Hizmetlerin durumunu gösteren paneldeki komutlar yenilendi. Tek bir servisin açık kalması halinde ayar
 • Hizmet Yönetimi > Bellek sıkıştma hizmetindeki komutlar düzenlendi.
 • Hizmet Yönetimi > Hizmet kontrol bölümüdeki komutlar yenilendi. Kapsamlı şekilde hizmetleri tarayıp durumunu yansıtacak şekilde ayarlamalar yapıldı.
 • OperaGX indirme bölümüne eklendi. 
 • AnyDesk uygulaması, Teamviewer altına alındı.
 • Windows Editör > Dism Update Online bölümünde güncelleme yükleme sonrası gelen restart sorgusu kaldırıldı.

:: ==============================================================================================================================
------------------
 ► Versiyon 2.7.1 - Ara güncelleme
------------------
Yayınlanma Tarihi: 18.04.2022

 • Icon Fix bölümüne Search App önbelliğini temizleyen komutlar eklendi. Bu komut ile arama bölümünde oluşan simge hataları giderilebilecek
   • Bu konuda tüm çözüm önerilerini deneyip çözümü bulan; "Legnica" ya teşekkür ederim.
   • Ayrıca; Yağız Murat Köse | Kaan Beyhan | Uğur 'a teşekkür ederim. 
 • AnyDesk uygulaması toolbox'a eklendi.
 • Windows Editör > Dism Update Online bölümünde güncelleme sonrası restart sorgusunu iptal etmek için parametre eklendi.

-----------------
 ► Versiyon 2.7 -
-----------------
Yayınlanma Tarihi: 18.04.2022

 • Hizmetleri Yönet > Windows Media Player yaşanan sorunlardan dolayı kaldırıldı.
 • Toolbox oto güncelleme sistemi getirildi. Bu özelliği OgnitorenKs.Toolbox klasörü içinde yer alan Update.ini'den kapatabilirsiniz.
 • Links.bat dosyası Links.txt olarak değiştirildi. Güncelleme işlemini hızlıca gerçekleştirmek için.
 • PowerChoice simgesi değiştirildi.

:: ==============================================================================================================================
-------------------
 ► Versiyon 2.6.3 - Ara güncelleme
-------------------
Yayınlanma Tarihi: 16.04.2022

 • Windows Editör > 24 - Katılımsız Program/Ayar ekle [Offline] bölümü kaldırıldı.
   • [Online] bölümü içindeki tüm komutlar yenilendi. Toolbox içindeki tüm programlar eklendi.
   • Masaüstüne dosya ekle bölümünü çalıştırdığınızda klasör penceresi otomatik açılacak şekilde ayarlandı.
   • Bilgilendirici mesajlar katılımsız aracın her bölümüne yerleştirildi.
   • Performans ile alakalı ayarlar tek bir bölümde toplandı.
 • Link sistemindeki bazı isimlerde değişiklik yapıldı. Bundan dolayı sorun yaşamamak için mutlaka toolbox'ı güncelleyin.
 • Wget yazılmı güncellendi.
 • Toolbox İngilizce ve 8.1 sürümlerine yeni toolbox simgesi eklendi.
 • Güncelleme sonrası temizlik bölümünden teslimat optimizasyonuyla alakalı bölüm çıkarıldı. Hataya sebep oluyordu.
 • Windows App Boss uygulaması kaldırıldı. Program çok uzun zamandır güncelleme almıyordu. Bu uygulama yerine Hibit Uninstaller kullanabilirsiniz.
 • Reiconcache yazılımı toolbox'tan kaldırıldı.
 • ISLC yazılımı indir - kur şeklinde düzenlendi.
 • Hizmet Yönetimi > Xbox bölümüne kısayol engelleyici parametre eklendi.
 • Hizmet Yönetimi > Windows Media player bölümüne yeni parametre eklendi.

-------------------
 ► Versiyon 2.6.2 - Ara güncelleme
-------------------
Yayınlanma Tarihi: 13.04.2022

 • Güncelleme sonrası temizlik bölümündeki hata giderildi.
 • Toolbox İngilizce sürümü Türkçe sürümü ile senkronize gelişecek şekilde yeniden düzenlendi.
 • Windows 8.1 Toolbox sürümü için Güncelleme ve katılımsız kurulum araçları eklendi.
 • Github'daki proje tek bir bölümde toplandı. TR / ENG / 8.1 sürüm dosya ve katılımsız araçları tek bir yerden sunulanacak.
   • İniglizce Toolbox hakkında detayları öğrenmek için "Google Translate" kullanılması gerekmektedir.
 • Güncelleştirme sonrası temizlik bölümündeki hizmetler "Extra\Update.After.bat" dosyasından toplandı.
   • PowerRun yazılımıyla tek bir işlem yapmak için tek bir .bat dosyasında topladım. 

-------------------
 ► Versiyon 2.6.1 - Ara güncelleme
-------------------
Yayınlanma Tarihi: 12.04.2022

 • Hizmetleri Yönet > Hizmetlerin açık veya kapalı olma durumları menü içinde belirtildi.
 • Hizmetleri Yönet > Baskı hizmetini aç kapat kaldırıldı.
 • Hizmetleri Yönet > Ip yardımcı bölümündeki yönlendirme hatası giderildi. 
 • Hizmetleri Yönet > Radyo ve uçak modu hizmeti bölümünde Windows 10 sistemlerdeki kapanma hatası giderildi.
 • Hizmetleri Yönet > Windows Search yönlendirme hatası giderildi.
 • Hizmetleri Yönet > Hyper - V kapat bölümündeki komut hatası giderildi.
 • PowerRun yazılımının yeninden indirme bölümünde yer alan komut hatası giderildi.
   • Hizmetleri Yönet bölümünde fazla işlem yapılınca antivirüs programı PowerRun yazılımdan huylanabiliyor. 

-----------------
 ► Versiyon 2.6 -
-----------------
Yayınlanma Tarihi: 10.04.2022

 • Ana menüde ve bazı iç bölümlerde farklı bölümlere açılan kısımlar için ifadeler yerleştirildi.
   • Menü bölümlerine [M] / Uygulama olarak açılan bölüme [APP] / ayrı pencere olarak açılacak bölüme [*] işareti bıraktım
   • "quanqx"a önerisi için teşekkür ediyorum.
 • Toolbox'ın bazı bölümlerinde yer alan linkler karmaşıklığı azaltmak için Links.bat dosyasına eklendi.
   • Links.bat / Setup.zip / ICO.zip dosyalarını drive linkleridir.
 • Güncelleme sonrası temizlik bölümnde Defender klasör artıklarını silme komutlarındaki parametre hatası giderildi.
 • "Hizmetleri yönet" > "GPU optimizasyon" bölümü kaldırıldı.
   • Bu tarz optimizasyonların GPU uygulamaları üzerinden kullanıcının kendi isteklerine göre düzenlemesini daha sağlıklı bulduğum için kaldırdım.
 • All in One Runtimes bölümündeki eski sürümleri kaldırmaya yarayan komutlar kaldırıldı. Yeniden yüklemelerde hataya sebep oluyordu.
   • Net Framework 3.5 / 4.5 / DirectPlay bölümleri önce kontrol edilip, yüklü olmaması durumunda komutlar çalışıp yükleme işlemini gerçekleştirecek.
   • All in One Runtimes yükleme bölümü arayüzü düzenlendi.
 • Toolbox simgesi değiştirildi.
 • Windows 10 Edit > Microsoft Store kaldırma bölümüne uyarı mesajı eklendi.
 • Hizmet yönetimi > "Radyo ve Uçak modu hizmeti" bölümü için Windows 11 kısıtlaması getirildi.
   • Bu servis kapatılınca ağ simgesi kaybolduğu için kısıtlama getirildi.
 • Sistem hakkında > Tarih ve saat bilgisi eklendi. (Archley'e katkısından ötürü teşekkür ederim.)
 • Hizmetleri Yönet > Telefon hizmeti bölümünde kapanma durumunda bluetooth hizmetlerinin kapatılması engellendi.
 • Hizmetleri Yönet > Hyper-V bölümünün işlem öncelikleri değiştirildi. Hyper-V bölümündeki bazı Dism komutları iptal edildi.
 • Windows Editör > Yeni Simgeleri yükle bölümündeki yol hatası giderildi.
 • Pc Temizle bölümündeki komutlar yenilendi. Başlık bölümü eklendi.
 • Windows / Store onar bölümüne başlık bölümü eklendi.
 • Windows Editör > Katılımsız Program/Ayar ekle [Online] - [Offline] bölümünde Nihai performans kısmında kod hatası giderildi.
 • Microsoft Teams indirme linklerinde yaşanan sorundan dolayı toolbox'tan kaldırıldı.
   • Katılımsız bölümünden de kaldırıldı.
 • Windows 10 Edit > Simge değiştir bölümündeki simge değişmeme sorunu tamamen çözüldü.
 • Windows / Market onar bölümündeki dll kayıt bölümündeki komutların okunması kolaylaştırıldı. For döngüsü içine alındı.
   • İşlem sonunda reset seçeneği bırakıldı.
 • Ping Ölçer bölümünün teması düzenlendi. Değişken bölümüne bilgilendirici metinler bırakıldı.
   • Yeni site ve dns adressleri eklendi.

:: ==============================================================================================================================

------------------
 ► Versiyon 2.5.2 - Ara güncelleme
------------------
Yayınlanma Tarihi: 03.04.2022

 • Hizmetleri Yönet > Uzak Masaüstü/Akış/Ağ hizmetleri bölümüne Windows Search hizmetini açmak için parametre eklendi.
 • Hizmetleri Yönet > Windows Search hizmetini açıp kapatmaya yarayacak bölüm eklendi.
 • "Güncelleme Sonrası Temizlik" bölümünde düzenlemeler yapıldı. "Hizmetleri Yönet" bölümünde açılacak hizmetleri tekrar kapatmaması için düzenlendi.

------------------
 ► Versiyon 2.5.1 - Ara güncelleme
------------------
Yayınlanma Tarihi: 01.04.2022

 • Toolbox içindeki regedit komutlarında düzenleme yapıldı.
 • Blitz uygulaması kurulum sorunlarından dolayı kaldırıldı.
 • Hizmetleri Yönet > Hyper-V bölümünde bilgi ekranındaki değişken hatası giderildi. Yeni parametre eklendi.
 • Taraycı eklentileri bölümündeki kod hatası giderildi.
 
-----------------
 ► Versiyon 2.5 -
-----------------
Yayınlanma Tarihi: 30.03.2022

 • Güncelleme sonrası temizlik bölümündeki regedit kayıtları düzenlendi. 
   • Kilitlenme sorununa neden olan regedit kayıtları kaldırıldı.
 • Hizmetleri Yönet > Bellek sıkıştırma aç-kapat bölümü eklendi.
 • Hizmetleri Yönet > Hyper-V bölümündeki komutlar düzenlendi.
   • Hata düzenlemesiyle ilgili düzenlemeyi paylaşan "maskem76"a teşekkür ederim.
 • Hizmetleri Yönet > Driver güncelleme aç-kapat bölümü eklendi.
 • Hizmetleri Yönet > İşlemci çekirdek park hizmeti aç-kapat bölümü eklendi. (Core Parking)
 • Hizmetleri Yönet > Tarayıcı ve Kamera hizmetleri bölümü birleştirildi.
 • Hizmetleri Yönet > GPU optimizasyon bölümü eklendi.
 • Microsoft Edge bölümüne reklam engelleyiciler engellendi.
 • "Windows 10-11 Edit" bölümünde yer alan yönlendirme hatası giderildi.
 • "Windows 10-11 Edit" bölümüne "Güncelleştirmeleri 2050 yılına kadar ertele" bölümü eklendi.

:: ==============================================================================================================================
-----------------
 ► Versiyon 2.4 -
-----------------
Yayınlanma Tarihi: 19.03.2022

 • Zaman ayarlı PC kapat bölümü eklendi.
 • Windows düzenleme bölümünden kaldırılanlar.
   • Silinmesi gerekenler
   • Windows 10 Hazır Regedit kayıtları
   • Windows 11 Hazır Regedit kayıtları 
 • Utorrent programı kaldırıldı. 
   • Yerine Qbittorrent programı eklendi.
 • Ana menü, alt bölümünde tasarım değişikliği yapıldı.
 • İngilizce dil destekli toolbox hazırlandı.
 • Windows 8.1 sürümü için toolbox hazırlandı.
 • Renk kodları basitleştirildi. Gereksiz kodlar kaldırıldı.
 • %konum% değişkeni %Location%, %deger% değişkeni %value% olarak değiştirildi.
 • Ekler klasörünün ismi Extra olarka değiştirildi.
 • Çoklu seçim yapılacak bölümler belirtildi.
 • Toolbox'ın her açılışta sürüm ve donanım bilgisi hakkında Log kaydı oluşturma sorunu giderildi.
   • Yapılan düzenleme ile sürüm farkı oluştuktan sonra yeni bir log kaydı tutulacak.
 • Powerchoice.bat, Extra klasörüne taşındı.
 • Process Hacker 2 sisteme eklendi.
 • Windows 10 Edit > Simge değiştir bölümündeki hata giderildi. Simgeler sorunsuz bir şekilde değiştirilebiliyor.
   • Komutlar optimize edildi. Değişim esnasında bekleme süresi azaltıldı.
 • Fat32 to NTFS bölümünde, X tuşu geri dönüş olarak belirtildi.

:: ==============================================================================================================================
-----------------
 ► Versiyon 2.3 -
-----------------
Yayınlanma Tarihi: 08.02.2022

 • İndirme linkleriyle ilgili bilgi güncellemesi artık yapılmayacaktır. Linkler düzenli olarak güncellenecektir.
 • Windows Düzenleme > ISO oluşturma bölümünde komutlar düzenlendi. Sanal makinalarda oluşan hata giderildi.
 • Windows Düzenleme > Katılımsız program ve ayar ekle > Bcdedit bölümüne Aygıt yöneticisinden "Yüksek duyarlılıklı olay süre ölçeri" kapatan parametre eklendi.
 • Windows Düzenleme > Regedit kayıt bölümlerine eklemeler yapıldı.
 • All in One Runtimes bölümüne yükleme işlemi öncesi eski sürümleri silme işlemi eklendi. 
 • All in One Runtimes bölümüne Net Framework 3.5/4.8/DirectPlay hizmetlerini aktifleştirmesi için komutlar eklendi.
 • Windows Düzenleme > Katılımsız program ve ayar ekle [Online] bölümündeki komut hatası giderildi.

:: ==============================================================================================================================
-----------------
 ► Versiyon 2.2 -
-----------------
Yayınlanma Tarihi: 26.01.2022

 • Windows Düzenleme > Setup düzenleme bölümünde Windows 11 Bypass aracında bilgi vermeden kapanma sorunu giderildi.
 • ISLC bölümündeki yol hatası giderildi. [Kick Furkanowski'e geri bildirimi için teşekkür ederim]
 • Signal indirme linki yenilendi. (5.28.0 > 5.29.0)
 • 7-Zip indirme linki yenilendi. (21.06 > 21.07)
 • Notepad++ indirme linki yenilendi. (8.2 > 8.2.1)
 • Mem Reduct indirme linki yenilendi. (3.3.5 > 3.4)
 • Hibit Uninstaller indirme linki yenilendi. (2.7.40 > 2.7.45)
 • İndirme bölümüne Blender uygulaması eklendi.
 • İndirme bölümüne Shotcut uygulaması eklendi.
 • İndirme bölümüne Openshot uygulaması eklendi.


:: ==============================================================================================================================
-----------------
 ► Versiyon 2.1 -
-----------------
Yayınlanma Tarihi: 21.01.2022

 • "Kapatılan Servisleri Yönet" bölümünde değişiklikler yapıldı.
   • Kod okunaklığını arttırmak için yorum satırları eklendi.
   • Sistem geri yükleme bölümüne bazı bağlı servisler eklendi.
   • Hyper-V hizmetini [Aç/Kapat] eklendi. 
     • Bu bölüm ile Home ve Home Single Language sistemlerde Hyper-V açmanız mümkün olacak.
   • Xbox hizmeti [Aç/Kapat] eklendi.
   • Bitlocker Sürücü şifreleme hizmeti [Aç/Kapat] eklendi.
   • Karma Gerçeklik hizmeti (VR) [Aç/Kapat] eklendi.
 • Windows Düzenleme > "Hyper-V ekle [Offline]" bölümü eklendi. 
   • Home ve Home Single Language sürümlerine Hyper-V ekleyebilirsiniz.
 • Windows 10 Edit > "Taskbar Hava Durumu [Aç/Kapat]" eklendi.
 • Windows 10 Edit > "Market [Yükle/Sil]" bölümünde düzenlemeler yapıldı.
 • "Güncelleme sonrası temizlik" bölümünde yorum satırları arttırıldı. Bazı eklemeler yapıldı.
 • Yeni simge dosyaları güncellendi. Windows 11 sürümü içindeki dosyalar alındı.

:: ==============================================================================================================================
-----------------
 ► Versiyon 2.0 -
-----------------
Yayınlanma Tarihi: 18.01.2022

 • Windows Düzenleme > "Yeni simgeleri yükle" bölümündeki yol hatası giderildi. 
 • Windows Düzenkene > "Katılımsız program ve ayar ekle [Online/Offline]" > Simge önbelleğini temizle seçeneği eklendi.
   • Simge değişikliği sonrası olası sorunlar için
 • OSU oyunu indirme bölümüne eklendi.
 • "Kapatılan Servisleri Yönet" bölümü düzenlendi.
   • Tüm servislere Aç / Kapat seçeneği eklendi.
   • İşlem yapmak için "1a" "3k" "4A" "10K" gibi yazmanız gerekmektedir. Tırnak işaretleri dahil değil
 • Hibit Uninstaller indirme linki yenilendi. (2.7.35 > 2.7.40)
 • Signal indirme linki yenilendi. (5.27.1 > 5.28.0) 
 • Python indirme linki yenilendi. (3.10.1 > 3.10.2)

:: ==============================================================================================================================
-----------------
 ► Versiyon 1.9 -
-----------------
Yayınlanma Tarihi: 11.01.2022

 • Gpedit.msc bölümündeki kod hatası giderildi. (Archley'e geri bildirimi için teşekkür ederim.)
 • Çoklu seçme bölümlerindeki kod hatası giderildi. (Geri dönüş kodları toolbox'ın kapanmasına neden oluyordu)
   • Windows Düzenleme > AIO bölümüne "X" geri çıkış tuşu yeniden eklendi.
   • Windows Düzenleme > ESD to WIM bölümüne "X" geri çıkış tuşu yeniden eklendi.
 • Desktop Runtime indirme linki yenilendi. (5.0.12 > 5.0.13)
 • Windows düzenleme > Windows 11 Edit > Sağ-tık Terminal bölümüne explorer reset komutu eklendi. 
 • Windows / Market Onar kodları düzenlendi.
 • Kapatılan servisler bölümünde değişiklikle yapıldı.
   • Uzak masaüstü ve akış bölümü birleştirildi. İki ayrı bölüm olunca sorunlar yaşanıyordu. 
   • Baskı hizmetlerini aç bölümü eklendi.
 • Güncelleştirme sonrası temizlik bölümünde düzenlemeler yapıldı.
 • All in One Runtimes bölümünde C++ linkleri yenilendi.
 • Microsoft Office bölümünde yaşanan sorundan dolayı Office uygulaması kaldırıldı. 
   • Adobe Reader yazılımı tekrar eklendi.

:: ==============================================================================================================================
-----------------
 ► Versiyon 1.8 -
-----------------
Yayınlanma Tarihi: 08.01.2022

 • Wifi Crack bölümü eklendi.
	• Bu bölümde sisteme girdiğiniz Wifi liste ve şifrelerini görebilirsiniz.
	• Çalışmasını toolbox'a eklediği için [Archley]'e teşekkür ederim.
 • Simge hatasını düzelt bölümüne yeni parametre eklendi.
 • Explorer Resetten sonra Explorer'ın açılmama hatası giderildi.
 • FAT32 to NTFS bölümü ana ekrandan ayrıldı. Yeni bölümde artık diskleri ve isimlerini görerek rahat bir şekilde işlem yapabilirsiniz.
 • Sistem hakkında bölümünün tüm komutları yenilendi. Eklenenler;
   • Windows 11 beta sürümlerinde Microsoft tarafından wmic uygulaması kaldırılmasından dolayı oluşan hata düzeltildi.
   • Saat dilimi 
   • HDD/SSD disk bilgisi
 • Kullanıcı Hesap Yönetimi bölümünde 7 numaralı bölümün kodları yenilendi.
 • "Çoklu indirme" bölümü "Listeyi Genişlet >>>" olarak değiştirildi. 52 işlem numarası "Z" olarak değiştirildi.
   • Liste genişletildiğinde Bonus bölümünde de programlar göreceksiniz. Bu bölümde zamanla yapılacak eklemeler için boş alanlar bıraktım.
   • Liste genişlet seçildiğinde artık çoklu seçim yapacaksanız. İki işlevi bir arada sundum.
 • Online katılımsız bölümündeki program listesi güncellendi. 
   • Mem Reduct yazılımı eklendi. Sessiz kurulum için Autoit ile script hazırladım.
   • Python / Microsoft Office 2019 / Stellarium / Recuva;
   • AOEMI Partition Assistans / Python / PhyCharm;
   • Visual Studio Code / Github / Git / İnternet Download Manager
   • World Of Tanks / Genshin Impact / Valorant oyunları eklendi.
   • TaskbarX bölümündeki kod hatası giderildi.
 • Signal indirme linki yenilendi. (5.26.1 > 5.27.1)
 • Steam indirme linki yenilendi.
 • Edge indirme linki yenilendi. (v96 > v97)
 • Libre Office indirme linki yenilendi. (7.2.4 > 7.2.5)
 • Krita indirme linki yenilendi. (5.0.0 > 5.0.2)
 • ShareX indirme linki yenilendi. (13.6.1 > 13.7.0)
 • K-Lite indirme linki yenilendi. (16.6.5 > 16.7.0)
 • Hibit Uninstaller indirme linki yenilendi. (2.7.15 > 2.7.35)
 •

:: ==============================================================================================================================

-----------------
 ► Versiyon 1.7 -
-----------------
Yayınlanma Tarihi: 01.01.2022
 
 • Toolbox Kullanım.md dosyası hazırlandı. (Toolbox'ın kullanımıyla ilgili tüm detaylar içinde yer almaktadır.)
 • Tekli bilgi mesajları menüden görüntelenecek şekilde düzenlendi.
 • Ana menüdeki geri dönüş sonrası yaşanan sorun düzeltildi.
 • Regedit yükleme bölümüne dosya kontrol sistemi getirildi.
 • Windows Düzenleme > "Setup Düzenleme" bölümündeki kodlar düzenlendi.
 • Windows Düzenleme > "Hızlı başlatma" bölümündeki kod hatası giderildi.
 • Lisans Yönetimi bölümündeki hatalar giderildi.
 • Bazı bölümlerdeki log oluşturamama sorunu giderildi.
 • Windows 10/11 Edit bölümünde bazı bölümlerden geri döndükten sonra işletim sistemi bilgisinin bozulma sorunu giderildi.
 • Windows Düzenleme > WIM Mount, Remount, Unmount, Setup Düzenleme, bölümlerindeki işlemleri Dism ile uygulanacak şekilde düzenlendi. İmagex komutları kaldırıldı.
 • Windows Düzenleme > "WIM Unmount" bölümüne bilgi ekranı eklendi.
 • Windows Düzenleme > AIO Windows Hazırla, ESD to WIM bölümlerinde "X" tuşu ile geri çıkma işlemi iptal edildi. Bazı durumlarda hataya neden oluyordu.
 • Kapatılan Servisler bölümü > Media player yönlendirme hatası giderildi.
 • Notepad++ indirme linki yenilendi. (8.1.9.3 > 8.2)
 • TaskbarX indirme linki yenilendi. (1.7.4.0 > 1.7.6.0)

:: ==============================================================================================================================
-----------------
 ► Versiyon 1.6 -
-----------------
Yayınlanma Tarihi: 29.12.2021

 • Windows Düzenleme > "Wim /Delete" çoklu seçme özelliği kaldırıldı. (İndex numaraları kaydığı için ilk silme işleminden sonra hatalı işlem yapıyordu)
 • Windows Düzenleme > Yol tanımlama bölümlerinde gereksiz komutlar kaldırıldı.
 • Windows Düzenleme > "AIO Windows Hazırla" çoklu seçme özelliğindeki hata giderildi.
 • Windows Düzenleme > Tüm bölümlerde "X" tuşu geri dönüş tuşu olarak ayarlandı.
 • Windows Düzenleme > "AIO Windows Hazırla" birleştirme bölümündeki eski tema sorunu giderildi.
 • Windows Düzenleme > "Telemetry engelle (Hosts)" bölümündeki yönlendirme hatası giderildi."
 • Sistem Hakkında > Sistem format tarihi eklendi. [Eray Türkay'a verdiği bilgi için teşekkür ederim]
 • Olası sorunlarda hızlı hata tespiti için log sistemi eklendi.
 • İndirme işlemlerinde internet durum kontrolü eklendi.
 • Toolbox.bat içinde yorum satırları arttırıldı. 
 
:: ==============================================================================================================================
-----------------
 ► Versiyon 1.5 -
-----------------
Yayınlanma Tarihi: 27 Aralık 2021

 • Windows Düzenleme > ISO hazırlama bölümüne etiket ve ISO isim verme özelliği eklendi.
 • Setup düzenleme bölümünde duraklamaya neden olan komut kaldırıldı.
 • WIM Mount bölümüne boot.wim çıkarma desteği eklendi. 
 • Kullanıcı hesap yönetimi bölümünde iç bölümlere X tuşu menüye dönüş olarak ayarlandı.
 • Sistem hakkında bölümünde Ram kısmına Soket yapısı eklendi. [Eray Türkay'a verdiği bilgi için teşekkür ederim]
 • İndirme işlemlerinde ilerleme çubuğu eklendi. [KaanBeyhan'a (DOGGEST) verdiği bilgi için teşekkür ederim]
 • TaskbarX indirme linki yenilendi. (1.7.3.0 > 1.7.4.0)

:: ==============================================================================================================================
-----------------
 ► Versiyon 1.4 -
-----------------
Yayınlanma Tarihi: 23 Aralık 2021

 • OgnitorenKs Toolbox Update aracına internet ve toolbox dosya kontrol sistemi getitirildi.
 • Windows edit bölümünde bazı bölümlerde yer alan buglar giderildi.
 • Katılımsız kurulum dosya hazırlama bölümünde düzenlemeler yapıldı. 
   • Online bölümüne internet bağlantı kontrol bölümü eklendi.
 • Windows 10 Edit bölümüne "Eski ve Yeni simgelere geçiş bölümü eklendi"
 • Signal indirme linki yenilendi. (5.26.0 > 5.26.1)
 • Kdenlive indirme linki yenilendi. (21.08.3 > 21.12.0)
 • Krita indirme linki yenilendi. (4.4.8 > 5.0.0)
 • Gimp indirme linki yenilendi. (2.10.28 > 2.10.30)
 • Audacity indirme linki yenilendi. (3.1.2 > 3.1.3)
 
:: ==============================================================================================================================
-----------------
 ► Versiyon 1.3 -
-----------------
Yayınlanma Tarihi: 22 Aralık 2021

 • İndirmeye devam et özelliği eklendi.
   • Bu özellik ile indirilmiş olan dosyalar tekrar indirilmeyecek. 
   • Herhangi bir sebepten ötürü Toolbox kapanırsa işlem tekrar edildiğin kaldığı yerden indirmeye devam edecektir.
 • Windows 10-11 Edit bölümleri işletim sistemine göre gösterilecektir. Windows 10'da 11'i | Windows 11'de 10 için ayrılan bölüm görünmeyecektir.
   • Home ve Home Single Language sistemlerde Gpedit.msc aktifleştirmek için ayar eklendi.
 • Terminal bölümündeki yönlendirme hatası giderildi.
 • Tema değiştirildi.
 • Sistem hakkında bölümünde Disk yapısını hatalı gösteren komut hatası giderildi.
 • Sistem - Market onar bölümünde düzenlemeler yapıldı. 
 • Ana ekran bilgi ekranına ve Sistem Hakkında bölümüne derleme numarası dahil edilmiştir. 
   • Derleme numarası (10.0.19043. ► 1348 ◄) Ok işaretleriyle gösterdiğim kısımdır. 
 • Katılımsız güncelleştirme aracının komutlarında düzenleme yapıldı.
 • Cheat Engine / Origin / Chrome bölümündeki kod hatası giderildi.
 • Toolbox içindeki tüm linkler "Ekler" klasöründe Links.bat içinde toplanmıştır.
 • Format Factory uygulaması sessiz kurulum işlemine imkan vermediği için kaldırıldı.
   • Any Video Converter uygulaması eklendi.
 • LightShoot uygulaması kaldırıldı. Offical sitesine Captcha doğrulaması geldiği için indirme yapılamıyor.
   •ShareX yazılımı eklendi. Her açıdan LightShoot uygulamasından çok daha iyi.	
 • Eagle Get uygulaması kaldırıldı. Program yapımcıları resmi siteyi kapatıp. Programı güncellemeyi bıraktılar.
 • OpenShell indirme linki güncellendi.
 • Edge indirme linki güncellendi.
 • ISLC programı eklendi.
 • Everything indirme linki yenilendi. (1.4.1.1009 > 1.4.1.1015)
 • Cheat Engine indirme linki yenilendi. (7.2 > 7.3)
 • Hibit Uninstaller indirme linki yenilendi. (2.7.10 > 2.7.15)
 • K-Lite Codec indirme linki yenilendi. (16.6.0 > 16.6.5)
 • 7 - Zip indirme linki yenilendi. (7.21.3 > 7.21.6)
 • Notepad++ indirme linki yenilendi. (8.1.9.2 > 8.1.9.3)
 • Libre Office indirme linki yenilendi. (7.2.2 > 7.2.4)
 • Signal indirme linki yenilendi. (5.25.0 > 5.26.0)
 • Windows 10 Market yükle bölümündeki kod hatası giderildi.
 • Kapatılan servisleri yönet bölümü eklendi.
 • Adobe Reader yazılımı yerine PDF-XChange Editör yazılımı eklenmiştir. Ücretsiz ve daha faydalı bulduğum için değiştirdim.  
 • Windows Edition bölümü eklendi. İçerisinde;
   • WIM / ESD Okuyucu eklendi 
   • AIO Windows Hazırla eklendi.
   • ISO Hazırla eklendi.
   • ESD to WIM / Çıkart eklendi.
   • WIM /Delete eklendi.
   • WIM [Yükle] eklendi.
   • WIM [Topla] eklendi.
   • Regedit [Yükle] eklendi.
   • Regedit [Topla] eklendi.
   • Dism Update [Online] eklendi.
   • Dism Update [Offline] eklendi.
   • Appx yükleyici [Offline] eklendi.
   • Appx yükleyici [Online] eklendi.
   • Driver Yedekle [Online] eklendi.
   • Driver yükle [Offline] eklendi.
   • Setup Düzenle [Offline] eklendi.
   • Yeni Simgeleri yükle[Offline] eklendi.
   • ISLC Ekle[Offline] eklendi.
   • Masaüstüne dosya ekle[Offline] eklendi.
   • OgnitorenKs.Toolbox ekle[Offline] eklendi.
 • Windows Düzenle bölümüne eklediğim aşağıdaki 2 bölüm ile sisteme katılımsız şekilde Toolbox'taki programlar dahil edilebilecek.
 • Online bölümündeki linkler oto link güncelleme sistemiyle sürekli güncel kalması için düzenleme yapılmıştır. 
 • Katılımsız program ve ayar ekle[Offline] eklendi.
 • Katılımsız program ve ayar ekle[Online] eklendi.


:: ==============================================================================================================================
-----------------
 ► Versiyon 1.2 -
-----------------
Yayınlanma Tarihi: 3 Aralık 2021

 • "Sahiplik al" ekleme bölümündeki kod hatası giderildi.
 • Hibit Uninstaller indirme linki yenilendi. (2.6.25 > 2.7.10)
 • Signal indirme linki yenilendi. (5.24.0 > 5.25.0)
 • Kdenlive indirme linki yenilendi. (21.08.2 > 21.08.3)
 • K-Lite Codec indirme linki yenilendi. (16.5.3 > 16.6.0)
 • NET Desktop Runtime indirme linki yenilendi. (5.0.11 > 5.0.12)
 • "Kapatılan Servisler Yönetim" bölümünde düzenlemeler yapıldı.
 • Fat32toNTFS bölümü işlemleri ana ekrandan yürütülecek şekilde düzenlendi.
 • Format Factory kurulum hatası giderildi.
 • Katılımsız güncelleştirme sistemi eklenmiştir.
   • OgnitorenKs.Toolbox klasörü içerisinde yer alan Toolbox.Update.bat dosyasını çalıştırarak güncelleme işlemini yapabilirsiniz.

:: ==============================================================================================================================
-----------------
 ► Versiyon 1.1 -
-----------------
Yayınlanma Tarihi: 26 Kasım 2021

 • Sunduğum diğer sistemlerde kapattığım bazı hizmetlerin yeniden açılması için Windows 10 ve Windows 11 edit bölümlerine eklemeler yaptım.
   • Bu bölüm ilk sürümde yer alan "Laptop hizmetlerini aç" "Yazıcı aktifleştir" bölümlerini de kapsamaktadır.
   • Servisleri toplu olarak açmak yerine ihtiyaç durumuna göre tek tek açılması üzerine düzenledim.
 • Olası ICO sorunu için hazırladığım IcoFix Toolbox'a entegre edildi.  
 • Skype kurulumunda x64 hatası verdiği için kaldırıldı.
   • Skype uygulamasının yerine Zoom uygulaması eklenmiştir. 
 • Blitz uygulamasındaki kurulum hatası giderildi.
 • Signal indirme linki güncellendi.(5.20 ► 5.24)
 • Audacity indirme linki güncellendi. (3.0.5 ► 3.1.2)
 • K-Lite Codec indirme linki güncellendi. (16.5.0 ► 16.5.3)
 • Format Factory indirme linki güncellendi. (5.8.1 ► 5.9.0)
   • Format Factory katılımsız kurulmamaktadır. Kurulum işlemlerinin manuel ilerletilmesi gerekmektedir.
   • Kurulumda dikkat edin farklı programlar kurdurmaya çalışmakta o seçenekleri kabul etmeyin.
 • TaskbarX indirme linki güncllendi. (1.7.2.0 ► 1.7.3.0)
 • SSDFresh uygulaması sistemsel bir arızaya neden olduğu için kaldırıldı
   • Alternatif olarak SSDBooster yazılımı eklendi. Portable bir yazılımdır ve masaüstüne indirilmektedir.
 • Sürüm notları Toolbox içine kısayol olarak eklendi.
 :: ==============================================================================================================================

 -----------------
 ► Versiyon 1.0 -
-----------------
Yayınlanma Tarihi: 23 Kasım 2021

 :: ==============================================================================================================================