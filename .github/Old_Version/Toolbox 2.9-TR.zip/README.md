
# OGNİTORENKS TOOLBOX
- Toolbox Windows 10 - 11 sürümlerinin x64 mimarilerinde açılmaktadır. Windows 8.1 için hazırladığım kısıtlı bir sürümü mevcuttur. En güncel olan Windows sürümü ile senkronize olarak gelişmektedir.
- Windows ekran ölçeklendirme ayarı Toolbox'ın pencere ayarını bozabiliyor. Sorunsuz kullanım için Toolbox'ı kullanırken ölçeklendirme etkileri kapatılmalıdır.

### Hazırlayan: Hüseyin UZUNYAYLA / OgnitorenKs
- ► Discord: OgnitorenKs#2737 
- ► Mail: ognitorenks@gmail.com
- ► Site: https://ognitorenks.blogspot.com/

![cmd_dqKt51jpOu](https://user-images.githubusercontent.com/93199689/165261666-69d60eaf-506d-4ce2-adc6-8e8f8ec9c20e.png)
![cmd_BbUuFhKN0l](https://user-images.githubusercontent.com/93199689/165261683-9a486357-3c00-4eb5-9248-dedf3b432677.png)

### Güncelleme Notları
- ► Toolbox TR/ENG : https://drive.google.com/file/d/1Le61P_h-O3R0F9KsMRR0dikvQxnQaPCC/view?usp=sharing
- ►    Toolbox 8.1 : https://drive.google.com/file/d/1pd3Ge7R1M9OlKP9qDMVObXLVmzm6kmxp/view?usp=sharing

### OgnitorenKs.Toolbox.zip dosyaları
- ► Toolbox.TR  = https://docs.google.com/uc?export=download&id=19uNjxzHFY5A6g4mFg8FirFTnyL2R0HZ3
- ► Toolbox.ENG = https://docs.google.com/uc?export=download&id=1vIa4FYNI6YS5l53Awusw4zS2IRvd6VFf
- ► Toolbox.8.1 = https://docs.google.com/uc?export=download&id=1k1Z3c1TE8a7K-lqKlozg6MJu_SPh3fmb
	
### OgnitorenKs.Toolbox katılımsız kurulum dosyaları
- ► Toolbox.TR  = https://docs.google.com/uc?export=download&id=19uNjxzHFY5A6g4mFg8FirFTnyL2R0HZ3
- ► Toolbox.ENG = https://docs.google.com/uc?export=download&id=1wTOKKhNr0JkpYaEM50KKJpRD3PTRL09e
- ► Toolbox.8.1 = https://docs.google.com/uc?export=download&id=12podfFYq5NujVr3mCHtMlyaa2nAFt-Em

### Toolbox Otomatik Güncelleme Sistemi
OgnitorenKs.Toolbox klasörü içerisinde yer alan Update.ini dosyasını not defteriyle düzenleyerek otomatik güncelleştirmeleri kapatabilirsiniz. Varsayılan olarak 0 yani güncelleştirmeler açık olarak düzenlenmiştir.
- 0 : Otomatik güncelleştirmeler açık
- 1 : Otomatik güncelleştirmeler kapalı

### Projeye katkıda bulunanlar;

	  ----------------------
	  ► Eray Türkay 
	  ----------------------
	  • Sistem Hakkında - RAM soket yapısının eklenmesi.
	  • Sistem Hakkında - Sistem format tarihinin eklenmesi.
	  ----------------------
	  ► KaanBeyhan [DOGGEST]
	  ----------------------
	  • İndirme işlemlerinde ilerleme çubuğunun eklenmesi.
	  ---------
   	  ► Archley
   	  ---------
	  • Wifi Crack çalışmasının toolbox'a eklenmesi.
	  ----------
	  ► maskem76
	  ----------
	  • Hyper-V bölümündeki hatanın giderilmesi.
	  ----------
	  ► Legnica
	  ----------
	  • Windows Search önbelliğinin temizlenmesiyle ilgili komutların eklenmesi.
	  -----------
	  ► Athenaus
	  -----------
	  • PowerChoice simgesinin değiştirilmesine katkı sundu.
	  -------------
	  ► EnixYazılım
	  -------------
	  • OperaGX yazılımının indirme bölümüne eklenmesi.
	  

# OGNİTORENKS TOOLBOX İÇERİĞİ
## 1 - Online Katılımsız Bölümü;

Bu bölümdeki programların hiçbiri ücretli değildir. Bütün programlar ücretsiz alternatifler arasında seçilmiştir. WinRaR hariç o da ücretli ama ücretsiz bir yazılımdır.	
   
	• 1 - All in One Runtimes: C++ 2005-2022 / Java / XNA Framework / OpenAL / DirectX. Bu programlar oyunlar ve bazı uygulamalarda sorun yaşamamanız için mutlaka kurulmalıdır.
#### ► Mesajlaşma Uygulamaları 
	• 2 - Discord: Sunucu kurup arkadaşlarınız sohbet edebileceğiniz bir uygulama. Online oyun oynuyorsanız arkadaşlarınızla iletişim kurmak için birebirdir.
	• 3 - Whatsapp: Telefondaki uygulamayı bilgisayarınıza senkronize etmeyi sağlar.
	• 4 - Signal: Telefondaki uygulamayı bilgisayarınıza senkronize etmeyi sağlar.
	• 5 - Telegram: Telefondaki uygulamayı bilgisayarınıza senkronize etmeyi sağlar.
	• 6 - Zoom: Skype benzeri uygulamadır. Eğitim amaçlı kullanılır. 
#### ► Oyun Uygulamaları 
	• 7 - EpicGames: Oyun kütüphanesi. Her hafta verdiği ücretsiz oyunlarla piyasada tanınır.
	• 8 - Steam: Oyun kütüphanesi. Bu kategorideki en popüler uygulamadır. 
	• 9 - GOG Galaxy= CD Project şirketine aittir. Eski birçok oyunu buradan satın alarak oynayabilirsiniz. Diğer oyun kütüphanelerini uygulamaya entegre edebiliyorsunuz.
	• 10 - Uplay: Ubisoft şirketinin oyun kütüphane uygulamasıdır.
	• 11 - Origin: EA Games şirketinin oyun kütühane uygulamasıdır.
#### ► Hile Uygulamaları 
	Online oyunlar için değil :)
	• 12 - Cheat Engine: Hile motorudur. Online oyunlarda denemeyin ban yeme ihtimaliniz yüksek. Hikayeli oyunlarda kullanılabilir. (Hileye hayır) 
	• 13 - Wemod: Hile kütüphanesidir. Yalnızca hikayeli oyunlarda işe yarar.
#### ► Tarayıcı Uygulamaları
	• 14 - Google Chrome: En çok kullanılan tarayıcıdır. 
	• 15 - Mozilla Firefox: Genellikle Linux sistemlerde kullanılır. Windows sürümünde de çok güzel özellik bulunmaktadır.
	• 16 - Brave: Chromium tabanlı tarayıcıdır. Entegre reklam engelleyicisi vardır. Google web mağazasından uygulama indirebilir. Cripto para cüzdanı gibi özellikleri var.
	• 17 - Microsoft Edge: Microsoft herkes kullansın diye Windows'un her yerine mayın gibi döşediği tarayıcıdır. Chromuim tabanlıdır. Hızlı bir tarayıcıdır. Google web mağazasına bağlanabilir.
	• 18 - OperaGX: Özel bir kullanıcı deneyimi sağlayan tarayıcı.
#### ► Ram Temizleme Uygulamaları
	• 19 - ISLC: RamStandby(bekleme) listesini temizlemeye yarayan uygulamadır.
	• 20 - Mem Reduct: Ram içinde boşta bekleyen tüm işlemleri kapatır. Oyunlarda bu temizleme işleminde kasma yaşanabilir.
#### ► Office Uygulamaları
	• 21 - LibreOffice: Microsoft Office uygulamasının ücretsiz alternatifidir. 
	• 22 - Adobe Reader: PDF dosyalarını açar.
	• 23 - PDF-XChange Editör: PDF dosyalarını düzenleyip, okuyabilirsiniz. Adobe Reader alternatifidir. Ücretsiz özellikleri bakımından Adobe Reader'den daha iyi bir uygulamdır.
	• 24 - Calibre: E-kitap formundaki dosyaları açıp, okumanızı sağlar.
#### ► Sıkıştırma Uygulamaları 
	• 25 - 7-Zip: Kullanıcılar genellikle WinRaR uygulamasını kullanır ancak 7-Zip yabana atılacak bir uygulama değildir.
	• 26 - WinRaR: Ücretli ama ücretsizdir! 
#### ► Video Düzenleme Uygulamaları
	• 27 - Kdenlive: Ücretsizdir. 92 MB civarında bir uygulamadır. Kullanımı çok basittir. Çıktı işlemlerinde ekran kartını kullanmama sorunu halledilirse çok iyi uygulamadır.
	• 28 - Openshot: Ücretsiz video düzenleme uygulamasıdır.
	• 29 - Shotcut: Ücretsiz video düzenleme uygulamasıdır.
#### ► Resim Düzenleme Uygulamaları
	• 30 - Krita: Adobe Photoshop uygulamasının ücretsiz alternatifidir. Steam uygulamasından satın alarak destekte olabilirsiniz. 
	• 31 - Gimp: Adobe Photoshop uygulamasının ücretsiz alternatifidir.
#### ► Ekran Kayıt (SS) Uygulamaları
	• 32 - OBS Studio: Ekran kaydı alma işlemi dışında canlı yayınlar içinde kullanılır. Kayıtlarınıza marka logosu atmaz.
	• 33 - ShareX: Ekran görüntüsü (SS) alma yazılımıdır. Ses kaydı almadan ekran kaydedebilir. GIF oluştabilir. Daha sayısız özellik bulunur.
#### ► Ses Düzeltme Uygulamaları
	• 34 - Audacity: Ses düzeltme uygulamasıdır. 
#### ► Multimedia Uygulamaları
	• 35 - K-Lite Codec: Video izleme uygulamasıdır. Açamayacağı video dosyası yoktur. 
	• 36 - VLC Media Player: Video izleme uygulamasıdır. Açamayacağı video dosyası yoktur. Videolarla ilgili çok fazla özelliğe sahiptir.
	• 37 - Aimp: Ses dosyalarını açmaya yarayan uygulamadır. Tasarım ve özellikle olarak çok beğendiğimi belirtmek isterim.
#### ► Dönüştürücü Uygulamaları
	• 38 - Any Video Converter: Video ses dönüştürme uygulamasıdır.
#### ► İndirme Uygulamaları
	• 39 - Free Download Manager: İndirme işlemlerinde kullanılacak yardımcı program. Torrent indirme desteğide bulunmaktadır.
	• 40 - Internet Download Manager: Free Download Manager ile hemen hemen aynı işlevlere sahiptir.
	• 41 - ByClick Downloader: Youtube'dan video indirmeye yarayan uygulamadır.
	• 42 - Qbittorrent: Torrent indirme yazılımıdır.
#### ► Diğer Uygulamalar
	• 43 - GlassWire: İnternet takip programı. Bilgisayarınızda hangi program nereye ne göndermiş ne almış hepsini görebilirsiniz.
	• 44 - TeamViewer: Bilgisayarlar arası uzaktan bağlantı sağlar.
	• 45 - AnyDesk: Bilgisayalar arası uzak bağlantı sağlar.
	• 46 - Hamachi: Ortak bir ağ kurmaya yarayan yazılımdır. Online oyunlarda arkadaşlarınızla oyun kurmak için ortak bir ağ gerektiğinde hayat kurtaran bir programdır.
	• 47 - Stremio: Torrent üzerinden film izleyebilirsiniz. İzlediğiniz veya izlemek istediğiniz filmeleri kütüphanenize ekleyebilirsiniz. 
	• 48 - MSI Afterburner: GPU fan ayarı yapar, SS alır, Video kaydı alır, oyunlarda donanımların kullanım değerlerini gösterir, voltaj değerlerini değiştirebilirsiniz.
	• 49 - Hibit Uninstaller: Kalıntı bırakmadan program kaldırmayı sağlar. Ayrıca çöp dosya temizler. Market uygulamalarını da kaldırabilir.
	• 50 - Wise Care 365: PC temizlik uygulamasıdır. Tek sürüme verilen ücretsiz pro sürümüdür.
	• 51 - Unlocker: Silinmeyen dosyaları silmeyi sağlar.
	• 52 - SSD Booster: SSD için sistemi optimize eder.
	• 53 - OpenShell: Alternatif başlat menüsüdür.
	• 54 - Everything: Sistemdeki dosyaları arayıp bulmanızı sağlar. Çok kullanışlı bir programdır.
	• 55 - TaskbarX: Başlat çubuğunu özelleştirmenizi sağlar.
	• 56 - Stellarium: Uzay bilgi uygulaması. Muazzam.
	• 57 - Recuva: Silinen dosyaları kurtarır.
	• 58 - AOMEI Partition Assistans: Disk yardımcı uygulaması.
#### ► IDE, Kod Editörleri ve Diğer Geliştirme Araçları
	• 59 - Python: Programlama dilidir.
	• 60 - PhyCharm: Python kod editörüdür.
	• 61 - Notepad++: Bilmeyen için not defteri uygulamasıdır. Yazılımcılar için kod editörüdür.
	• 62 - Visual Studio Code: Visual Studio'nun editör halidir. Genelde web geliştirme için kullanılır.
	• 63 - Github Desktop: Grafik arayüzlü bir git istemcisidir.
	• 64 - Git: Dağıtım takip sistemidir.
	• 65 - Blender: Ücretsiz, açık kaynaklı bir çalışmadır. 3D tasarımlarda kullanılacak mükemmel uygulama.
#### ► Diğer
	• 66 - Process Hacker 2: Görev Yöneticisi
#### ► Oyunlar
    • 72 - OSU!: Müzik video oyunduur.
    • 73 - World Of Tanks: Online tank oyunu.
    • 74 - Genshin Impact: Online oyundur.
    • 75 - League Of Legends[TR]: Riot Games'in oyunudur. 5 vs 5 şeklinde karşılaşma yapılır.
    • 76 - League Of Legends[EUW]: Riot Games'in oyunudur. 5 vs 5 şeklinde karşılaşma yapılır.
    • 77 - Blitz: League Of Legends oyununun yardımcı uygulamasıdır. Hile değildir, ban yeme riski yoktur. Oyun içi rehber görevi görür.
    • 78 - Valorant: Riot Games'in CS:GO tarzı oyunudur.
# BONUS
	• 53. - Bu bölüm işletim sistemine göre değişiklik göstermektedir. Windows 11 ve Windows 10 için iki ayrı bölüme ayrılmıştır.
### • 53 - Windows 10 Düzenleme
![explorer_1SrOAqZP9Q](https://user-images.githubusercontent.com/93199689/160884988-ec36351b-11d1-449f-a5fa-3c162accc7e0.png)

	• 1 - Taskbar saat yanı simge ayarı [GÖSTER/GİZLE]: 
	     •[Göster]: 0 - Saat yanında yer alan tüm simgeleri gösterir.
	     •[Gizle]: 1 - Saat yanında yer alan simgelerden ağ ve ses dışındaki simgeleri "▲" içine alır
		
	• 2 - Bildirim Alanı [Aç/Kapat]: 
	     •[Aç]: 0 - Saat sağında yer alan bildirim alanını açar.
	     •[Kapat]: 1 - Saat sağında yer alan bildirim alanını kapatır.
		
	• 3 - Sahiplik Al [Ekle/Kaldır]: Bazı sistem dosyalarında yetki sorunu yaşadığınızda imdadınıza yetişecek bölümdür.
	     •[Ekle]: 1 - Sağ-tık bölümüne "Sahiplik Al" butonunu ekler.
	     •[Kaldır]: 2 - Sağ-tık bölümünden "Sahipli Al" butonunu kaldırır.
	     
	• 4 - Taskbar Hava Durumu [Aç/Kapat]:
	     •[Kapat]: 0 - Görev çubuğundaki hava durumu simgesini kaldırır.
	     •[Aç]:	1 - Görev çubuğundaki hava durumu simgesini ve ayarlarını geri getirir.
		
	• 5 - Market [Yükle/Kaldır]:
	     •[Kaldır]: 1 - Kaldırılabilir bütün market uygulamalarını siler.
	     •[Yükle]: 2 - Market uygulamasını yeniden yükler.
		
	• 6 - CompactOS (Windows Sıkıştırma) [Aç/Kapat]: Windows sistem dosyalarını sıkıştırarak 3 - 4 GB'lık bir alan kazanmanızı sağlar. Performans kaybı yaratmaz.
	     •[Aç]: 1 - Windows sistem dosyalarını sıkıştırmayı açar.
	     •[Kapat]: 2 - Windows sistem dosyalarını sıkıştırmayı kapatır.
		
	• 7 - Gpedit.msc (Yerel Grup ilkesi) [Ekle]: Windows Home ve Home Single Language sürümlerine "Gpedit.msc" ekler.
	
	• 8 - Simgeleri Değiştir [Eski/Yeni]: 21H2 beta sürümünde gelen ancak iptal edilen simgeleri sisteme yükler. Bu bölüme ilk girişinizde simge dosyalarını indirecektir!
	     •[Eski]: 1 - Windows 10 eski (Varsayılan) simgeleri yükler.
	     •[Yeni]: 2 - Windows 10 yeni simgeleri yükler.
	• 9 - Güncellemeleri 2050 yılına kadar ertele: Windows Update hizmetini 2050 yılına kadar etkisiz hale getirir.
### • 53 - Windows 11 Düzenleme
![cmd_ZsZUD6Foll](https://user-images.githubusercontent.com/93199689/160885045-b7edf8bb-d765-42aa-8393-89d774affbfc.png)

	• 1 - Taskbar Boyut [Küçük/Orta/Büyük]: 22H2'de çalışmıyor.
	     •[Küçük]: 0 - Görev çubuğunu küçük yapar.
	     •[Orta]: 1 - Görev çubuğunu varsayılan haline getirir.
	     •[Büyük]: 2 - Görev çubuğunu büyük yapar.
		
	• 2 - Taskbar Konumu [Alt/Üst]: 22H2'de çalışmıyor.
	     •[Alt]: 1 - Görev çubuğunu alt bölüme alır.
	     •[Üst]: 3 - Görev çubuğunu üst bölüme alır
		
	• 3 - Taskbar Simge Konumu [Sol/Orta]:
	     •[Sol]: 0 - Görev çubuğundaki simgeleri sola dayar.
	     •[Orta]: 1 - Görev çubuğundaki simgeleri ortalar. (Varsayılan)	
		
	• 4 - Sağ-tık Menü [Eski/Yeni]:
	     •[Eski]: 1 - Sağ-tık menüsünü Windows 10'daki gibi yapar.
	     •[Yeni]: 2 - Sağ-tık menüsünü Windows 11'deki gibi yapar. (Varsayılan)
		
	• 5 -Sağ-tık terminal [Ekle/Kaldır]:
	     •[Kaldır]: 1 - Sağ-tık menüsünden terminal'i kaldırır.
	     •[Ekle]: 2 - Sağ-tık menüsüne terminal ekler. (Varsayılan)
		
	• 6 - Sahiplik Al [Ekle/Kaldır]: Bazı sistem dosyalarında yetki sorunu yaşadığınızda imdadınıza yetişecek bölümdür.
	     •[Ekle]: 1 - Sağ-tık bölümüne "Sahiplik Al" butonunu ekler.
	     •[Kaldır]: 2 - Sağ-tık bölümünden "Sahiplik Al" butonunu kaldırır.
	
	• 7 - CompactOS (Windows Sıkıştırma) [Aç/Kapat]: Windows sistem dosyalarını sıkıştırarak 3 - 4 GB'lık bir alan kazanmanızı sağlar. Performans kaybı yaratmaz.
	     •[Aç]: 1 - Windows sistem dosyalarını sıkıştırmayı açar.
	     •[Kapat]: 2 - Windows sistem dosyalarını sıkıştırmayı kapatır.
		
	• 8 - Gpedit.msc (Yerel Grup ilkesi) [Ekle]: Windows Home ve Home Single Language sürümlerine "Gpedit.msc" ekler.
	• 9 - Güncellemeleri 2050 yılına kadar ertele: Windows Update hizmetini 2050 yılına kadar etkisiz hale getirir.
### • 54 - Kapatılan Servisleri Yönet
Bu bölümü kullanmak için işlem yapacağınz bölümün numarasını girip daha sonra aç / kapat baş harflerini eklemek gerekiyor.

Örnek: 1a / 2k / 4A / 10K / 23a / 24k  
![cmd_vwsKR6Zjrd](https://user-images.githubusercontent.com/93199689/164455235-b5b4211d-ee39-48ce-94b5-11f38e5ffd2b.png)

	• 1 [A/K]- Bluetooth hizmeti : Bluetooth hizmetlerini kapatır açar.
	• 2 [A/K]- Yazıcı hizmeti : Yazıcı hizmetlerini kapatır açar.
	• 3 [A/K]- Telefon hizmeti : Telefon uygulamasına ait hizmetleri kapatır açar.
	• 4 [A/K]- Tarifeli ağları : Kotalı internetiniz var, kota aşımını önlemek için bu hizmeti kullanabilirsiniz. (Nasıl oluyor hiç bilmiyorum, yalnızca hizmeti açıyorum :D)
	• 5 [A/K]- IP Yardımcısı (IPv6) : IPv6 destekli internet hizmetiniz var ise bu hizmeti açın.
	• 6 [A/K]- Mobil Etkin Nokta (Hotspot) : Kullandığınız cihazdan interneti paylaşmanızı sağlayayacak donanım var ise buradan hizmeti açabilirsiniz.
	• 7 [A/K]- Radyo ve Uçak modu hizmeti : Laptoplarda kullanılacak hizmettir. Windows 11'de bu hizmet kapalı olunca ağ simgesi görünmüyor. 
	• 8 [A/K]- Uzak Masaüstü/Akış/Ağ hizmetleri : Aynı ağı kullanan cihazları görmek ve ekrana yansıtma, aktarma, uzak masaüstü hizmetleri için gerekli hizmetleri kapatır, açar.
	• 9 [A/K]- Windows Search: Indexleme hizmetini açar.
	• 10 [A/K]- Windows Şimdi Bağlan (WPS) : WPS özelliğini kullanmanızı sağlayan hizmeti açar.
	• 11 [A/K]- Tarayıcı ve Kamera hizmetleri : Tarayıcı ve Kamera cihazlarını için gerekli olan hizmetleri açıp kapatır.
	• 12 [A/K]- Insider hizmeti : Windows ön sürümlerini erkenden deneyimleyip hataları bulup bildirmek gibi bir koca yüreğiniz var ise bu servisi aktif ederek. Insider sürüme kayıt olunuz.
	• 13 [A/K]- Biyometrik Hizmeti : Kullanıdığınız cihazda parmak okuyucu tarzı cihazlar var ise sorunsuz kullanmanız için açar.
	• 14 [A/K]- Kalem ve Dokunmatik Klavye hizmetini : Dokunmatik destekli cihazınız var ise sorunsuz kullanmanız için hizmetleri açar.
	• 15 [A/K]- Sistem geri yükleme hizmeti : Sistem geri yükleme hizmetini açar.
	• 16 [A/K]- Sysmain (Hızlı Getir) : Windows daha hızlı deneyim sunması için diski daha fazla kullanır. Yüksek disk kullanımına sebebiyet verir. SSD varsa gereksizdir. Kullanırsanız hizmeti açar.
	• 17 [A/K]- Hızlı Başlat (Hibernate) : Sistem önbellekleme yaparak hızlı açılmasını sağlar. Ancak kapanmama gibi sorunlara neden olmaktadır. Kullanmak isterseniz hizmeti açar.
	• 18 [A/K]- Konum hizmetini : Bilgisayarlarda bu özelliği hep gereksiz bulmuşumdur. Laptop cihazınız konumunuzu tam olarak tespit edebiliyorsa açın. Yoksa hiç açmayın.
	• 19 [A/K]- Hyper-V hizmetini: Home ve Home Single Language sistemlerde bile Hyper-V açıp kapatmanızı sağlar.
	• 20 [A/K]- Xbox hizmetini: Xbox servislerini kapatıp, açar.
	• 21 [A/K]- Bitlocker Sürücü şifreleme hizmeti: Sürücü şifreleme hizmetini kapatır açar.
	• 22 [A/K]- Karma Gerçeklik hizmeti (VR): Karma gerçeklik kapatır açar.
	• 23 [A/K]- Driver Yükle / Güncelle (Update): Windows Update üzerinden Driver güncellemesini açıp, kapatmanızı sağlar.
	• 24 [A/K]- Bellek Sıkıştırma hizmeti: Bellek içindeki verinin belli bir bölümünü sıkıştıran hizmeti kapatır ve açar. Gecikme düşürmek için hizmet kapalı tutulabilir.
	• 25 [A/K]- Core Parking (CPU Çekirdek Uyku Modu): İşlemci çekirdeklerinin sürekli tam yükte çalışmasını istiyorsanız hizmeti kapatabilirsiniz. Tam tersi durum için açık hale getirebilirsiniz.
	
### • 55 - Simge Hatasını Düzelt: 
	• Simgeleri değiştirdikten sonra oluşacak sorunları giderir.
### • 56 - Windows Düzenleme:
Mavi renkli işlem numaraları 26 numaralı işlem ile alakalıdır.

![cmd_gjMiAPFnpU](https://user-images.githubusercontent.com/93199689/163688060-ee63fdaa-a327-493f-9ad5-0b9746c855fd.png)

	• 1 - WIM / ESD Okuyucu: install.wim ve install.esd dosyalarının içeriği hakkında bilgi verir.
	• 2 - AIO Windows Hazırla: İnstall.wim sürümlerini birleştirmeye yarar. "X" tuşu burada çalışmaz.
	• 3 - ISO Hazırla: Windows format dosyalarını ISO'ya dönüştürür. "Edit" klasörü içerisinde .iso dosyanızı bulabilirsiniz. "X" tuşu burada çalışmaz.
	• 4 - ESD to WIM [Dönüştür]: install.esd dosyalarını install.wim olarak dönüştürür. Çoklu seçim yapılabilir. Çoklu seçimlerde seçim arasına virgül koyun. "Örnek; 1,2,3,4" 
	• 5 - WIM /Delete: install.wim içinde yer alan istemediğiniz sürümleri silebilirsiniz. Çoklu seçim imkanı yoktur.
	• 6 - WIM Mount: install.wim dosyasını klasöre çıkarır.
	• 7 - WIM Remount: Mount edilen dosya toplanmadan bilgisayar resetlenirse klasörü toparlamak veya işlem yapmak için yeniden yüklenmesi gerekir.
	• 8 - WIM Unmount: Mount edilen dosyaları toplar
	• 9 - Regedit [Yükle]: Offline sistemin regedit kayıtlarını online sisteme entegre ederek değişim yapmanızı sağlar. Detaylı bir konudur. Bu konularda tecrübeniz yoksa bulaşmayın.
	     • Bu bölümü kullanmadan önce sistemi farklı bir program ile mount ettiyseniz programı kapatın. Yoksa hata alırsınız.
	     • Offline sisteme eklenilen regedit kayıtları online sistemden farklı tepkiler verecektir. Lütfen bu durumu göz önünde bulundurun.
	     • -------------------------------------------------------------------------------
	     •                 Varsayılan Yol       Entegre edilmiş hali
	     •                ---------------       --------------------
	     •                 [HKLM\SOFTWARE]  ► ► [HKLM\OG_SOFTWARE]
	     •                          [HKCR]  ► ► [HKLM\OG_SOFTWARE\Classes]
	     •                   [HKLM\SYSTEM]  ► ► [HKLM\OG_SYSTEM]
	     •                          [HKCU]  ► ► [HKLM\OG_NTUSER]
	     •                  [HKU\.Default]  ► ► [HKLM\OG_DEFAULT]
	     • [HKLM\SYSTEM\CurrentControlSet]  ► ► [HKLM\OG_SYSTEM\ControlSet001]
	     • -------------------------------------------------------------------------------
	     • ► Örnek 1:
	     • ----------
	     • [Varsayılan Yol]: reg add "HKLM\SOFTWARE\Microsoft\Speech_OneCore\Preferences" /v "ModelDownloadAllowed" /t REG_DWORD /d 0 /f
	     • [Entegre edilmiş hali]: reg add "HKLM\OG_SOFTWARE\Microsoft\Speech_OneCore\Preferences" /v "ModelDownloadAllowed" /t REG_DWORD /d 0 /f
	     • ----------
	     • ► Örnek 2:
	     • ----------
	     • [Varsayılan Yol]: Reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" /v "EnableWebContentEvaluation" /t REG_DWORD /d 0 /f
	     • [Entegre edilmiş hali]: Reg add "HKLM\OG_NTUSER\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" /v "EnableWebContentEvaluation" /t REG_DWORD /d 0 /f
	     • ----------
	     • ► Örnek 3:
	     • ----------
	     • [Varsayılan Yol]: Reg add "HKU\.Default\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" /v "PreventOverride" /t REG_DWORD /d 0 /f
	     • [Entegre edilmiş hali]: Reg add "HKLM\OG_DEFAULT\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost" /v "PreventOverride" /t REG_DWORD /d 0 /f
	     • ----------
	     • ► Örnek 4:
	     • ----------
	     • [Varsayılan Yol]: reg add "HKCR\*\shell\runas" /ve /t REG_SZ /d "Sahipliği Al" /f 
	     • [Entegre edilmiş hali]: reg add "HKLM\OG_SOFTWARE\Classes\*\shell\runas" /ve /t REG_SZ /d "Sahipliği Al" /f 
	     • ----------
	     • ► Örnek 5:
	     • ----------
	     • [Varsayılan Yol]: "HKLM\SYSTEM\CurrentControlSet\Control\FileSystem" /v "LongPathsEnabled" /t REG_DWORD /d 1 /f
	     • [Entegre edilmiş hali]: "HKLM\OG_SYSTEM\ControlSet001\Control\FileSystem" /v "LongPathsEnabled" /t REG_DWORD /d 1 /f
	     • -------------------------------------------------------------------------------
	• 10 - Regedit [Topla]: Yüklenilen regedit kayıtlarını toplar. Regedit kayıtlarını yüklerseniz toplamayı unutmayın. Yoksa diğer programlarda hata alırsınız.
	• 11 - Dism Update [Online]: Windows update dosyalarını yüklü sisteme yükler. Update dosyalarını "Edit\Update" içine atınız.
	• 12 - Dism Update [Offline]: Windows update dosyalarını offline sisteme yükler. Update dosyalarını "Edit\Update" içine atınız.
	     • Sisteme güncelleme kurmak için Microsoft Update Catalog sitesinden Windows sürümünüzü yazarak arama yapın.
		• Çıkan arama sonuçlarında "Cumulative" yazan son güncelleştirmeyi indirip yükleyin. Önceki sürümleri de kapsamaktadır. 
		• Güncelleme dosyalarını indirmek için: 
		  • ► https://www.catalog.update.microsoft.com/
	• 13 - Appx Yükleyici [Offline]: Market uygulama paketlerini offline sisteme yükler. Yükleme dosyalarını "Edit\Appx" içine atınız
	• 14 - Appx Yükleyici [Online]: Market uygulama paketlerini online sisteme yükler. Yükleme dosyalarını "Edit\Appx" içine atınız
	     • Appx dosyalarının indirmek için; 
		• ► https://store.rg-adguard.net/
	• 15 - Driver Yedekle [Online]: Yüklü sistemden Driverları yedekler. Yedeklediği konum "Edit\Driver\Yedek"
	• 16 - Driver Yedekle [Offline]: Offline sisteme driver entegre eder. Driver dosyalarını "Edit\Driver" klasörü içine atın. Yedek aldıktan sonra bu bölümü seçerseniz, yedekleri imaja yükler.
	• 17 - Setup Düzenle [Offline]: Windows yükleme dosyalarını özelleştirir. İlk girişte "Files\setup10.zip" dosyasını indirir. Kendinize özel bölüm oluşturmak istiyorsanız. Aşağıdaki linke bakınız.
	• 18 - Yeni simgeleri yükle [Offline]: Yeni simgeleri imaja entegre eder. İlk girişte "Files\Newico.zip" dosyasını indirir. 
	• 19 - Gpedit.msc ekle [Offline]: Offline sistemden Windows Home ve Home Single Language sürümlerine ekleyebilirsiniz.
	• 20 - Hyper-V ekle: Home ve HomeSingle Language sürümlerinin imajlarına Hyper-V ekler.
	• -------------------------------------------------------------------------------------------------------------------------
	• 21 - Katılımsız program ve ayar ekle : Offline sisteme indir, kur, sil olarak program entegre eder.
	     • Bu bölümde program eklemek isterseniz öncelikle 74 -Katılımsız dosyası oluştur uygulayın. Ondan sonra dilediğiniz programı ekleyin.
	     • Program ve ayar ekleme işlemi bittikten sonra 75 - Katılımsız dosyasını tamamla uygulayın. 
	     • 75 numaralı işlemi uyguladıktan sonra yedek almak isterseniz. 76 - Katılımsız Yedekle uygulayın. Yedek dosyasını masaüstüne atacaktır.
	     • 77 - Yedekten ekle ile yedeklediğiniz .zip dosyasının yolunu tanımlayarak offline sisteme entegre edebilirsiniz.
	     • Çoklu seçim özelliği yoktur. Görsel aşağıda
	• -------------------------------------------------------------------------------------------------------------------------
	• 22 - Mount yol tanımla: Bu bölüm 9 - 12 - 13 - 16 - 18 - 19 - 20 - 21 bölümleriyle bağlantılıdır. 
	     • Burada tanımlanan klasör yolu ile işlem yapılmaktadır.
	     • Bu bölüm ilk girişte "Edit\Mount" klasör yolunu alır. Mount dosyaları farklı bir klasörde ise 26 numaralı işlem ile değiştirin.
	     
![cmd_gAsBVf0Vow](https://user-images.githubusercontent.com/93199689/163688053-e0b7d94d-3744-4e16-bca2-d5f09ce5c6dc.png)

### • 57 - Güncelleme Sonrası Temizlik:
	• Güncelleme sonrası yüklenen Defender, Telemetri, Diagtrack gibi hizmetleri yeniden kapatır.	
### • 58 - Sistem / Market Onar:
	• Microsoft'un önerdiği bütün onarma seçeneklerini uygular.
### • 59 - PC Temizle:
	• Sistemde biriken çöp dosyaları temizler.	
### • 60 - Folder to ISO: 
	• Folder to ISO uygulamasını açar. Klasör içindeki verileri ISO dosyasını çevirir.
	• Resmi sayfası: https://www.trustfm.net/software/utilities/Folder2Iso.php
![Folder2Iso_1FDJViSHXt](https://user-images.githubusercontent.com/93199689/162618820-6233dc42-31d4-471f-8ad9-a0bf44e2faab.png)	
	
### • 61 - Fat32 to NTFS: 
	• Fat32 olarak formatlanmış USB diskleri veri kaybı olmadan NTFS'ye çevirir. Disk harfini girmeniz gerekmektedir.
![cmd_tokNcw69mr](https://user-images.githubusercontent.com/93199689/162618533-9f18c20e-165e-4ef7-bdf9-3e6b590591cb.png)

### • 62 - Ping Ölçer: 
	• İçerisinde belirli sitelerin ping durumlarını otomatik gösterir. Alt bölümde yer alan "Ping ölç" bölümüyle istediğiniz site ve IP'nin pingini ölçebilirsiniz.
![cmd_MBrlUEjJp8](https://user-images.githubusercontent.com/93199689/162618549-62169dab-05d1-4c1f-9404-a4f616b7936f.png)

### • 63 - Lisans Yönetimi: 
SLMGR.VBS komutlarını içermektedir. Crack tarzı işlemler bulunmamaktadır.

![LisansYonetimi](https://user-images.githubusercontent.com/93199689/148984026-2f91e49b-5fd0-4a14-85b0-aeab3ffa1d48.png)

	• 1 - Lisans Gir [ipk]: Lisans numaranızı girerek sistemi lisanslayabilirsiniz.
	• 2 - Lisans Durumu [dli]: Lisans durumu hakkında bilgi verir.
	• 3 - Lisans Durumu Detaylı [dlv]: Lisans durumu hakkında detaylı bilgi verir.
	• 4 - Lisans Süresini Öğren [xpr]: Lisans süresi hakkında detaylı bilgi verir.
	• 5 - Lisans Sil [upk]: Sistem kullandığınız lisansı siler.
	• 6 - Lisans Süre Sıfırla [rearm]: Windows 30 günlük deneme sürümü süresini 3 defa uzatabilirsiniz. 
### • 64 - Kullancı Hesap Yönetimi: 
![KullanıcıHesabı](https://user-images.githubusercontent.com/93199689/148984022-2d26e786-5d72-4941-9753-c7ff7e923927.png)

	• 1 - Administrator [AKTİF]: Administrator hesabını açar.
	• 2 - Administrator [PASİF]: Administrator hesabını kapatır.
	• 3 - Admin grubuna kullanıcı ekle: Admin grubuna kullanıcı eklersiniz.
	• 4 - Kullanıcı [EKLE]: Yeni kullanıcı oluşturabilirsiniz.
	• 5 - Kullanıcı [SİL]: Mevcut bir kullanıcıyı silebilirsiniz.
	• 6 - Şifremi unuttum: Şifre değiştirmek veya şifre oluşturmak için bu bölüm kullanılabilir.
	• 7 - Mevcut Kullanıcıları Göster: Sistemde kayıtlı kullanıcıları gösterir.
### • 65 - Sistem Hakkında:
- Sistem ve donanım hakkında bilgi verir.
![cmd_a013zdbIKc](https://user-images.githubusercontent.com/93199689/162618566-48b7bcd6-2bad-4b85-893d-5ef16cc655e6.png)

### • 66 - Wifi Crack:	 
	• Bu bölümde sisteme girdiğiniz Wifi isim ve şifrelerini görebilirsiniz.
	• Çalışmasını toolbox'a eklediği için Archley'e teşekkür ederim.
### • 67 - Zaman Ayarlı PC Kapat:
	• Seçilen belirli bir süreden sonra PC otomatik kapatır.
![cmd_ScVQsUrVYT](https://user-images.githubusercontent.com/93199689/159128693-a8d1d252-5649-42db-8610-e9df435e6952.png)

### • 98 - Toolbox Rehber:
	• Toolbox kullanımı hakkında tüm bilgileri verir
### • 99 - Toolbox Güncelle:
	• Toolbox sürümünüzü buradan tek tıkla güncelleyebilirsiniz. Toolbox konumunu değiştirdiyseniz yeniden "C:\OgnitorenKs.Toolbox" klasörüne kuracaktır.	
